# Dictionary editor visual-preview update

## Included changes

- Read-only value cells now show semantic preview icons for colour, line style,
  marker, colormap, hatch, font, join style and cap style.
- Colour editing uses Qt's standard `QColorDialog` through `ColorPickerButton`.
- Added `HatchStyleCombo` with hatch-pattern previews and editable custom tokens.
- Font entries and read-only font values show an `Aa` sample rendered in the
  selected family.
- Added visual join-style (`miter`, `round`, `bevel`) and cap-style (`butt`,
  `round`, `projecting`) combos.
- Existing colour, line, marker and colormap modules expose public preview-icon
  functions for reuse by the property tree.

## New files

Place these in `app/widgets/drop_down_controls/`:

- `color_picker.py`
- `hatch_combo.py`
- `edge_style_combo.py`

Replace the existing versions of:

- `color_combo.py`
- `colormap_combo.py`
- `font_combo.py`
- `icon_combo.py`
- `line_combo.py`
- `marker_combo.py`

Replace the existing dictionary editor with `dictionary_editor.py` at its
current project location.

## Schema recognition

`hatch` is automatically recognised as kind `hatch`. Explicit schema metadata
can also use `{"kind": "hatch"}`. Existing `joinstyle`, `capstyle`,
`fontlist`, `color`, `linestyle`, `marker` and `colormap` kinds remain
supported.

## Alias and dotted rcParam mappings

This patch maps artist aliases and dotted rcParams to the visual widgets,
including colour aliases, `ls`, `negative_linestyle`, solid/dash join styles,
solid/dash cap styles, hatch, colormap and font-family keys. Join and cap styles
have dedicated preview combos and read-only tree icons. The Matplotlib style
editor now delegates `*.hatch` settings to the hatch preview widget.
