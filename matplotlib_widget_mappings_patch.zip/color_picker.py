# -*- coding: utf-8 -*-
"""Compact colour editor backed by Qt's standard QColorDialog."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtGui import QColor, QIcon
from PySide6.QtWidgets import QColorDialog, QPushButton, QWidget

from app.widgets.drop_down_controls.color_combo import color_preview_icon


class ColorPickerButton(QPushButton):
    colorChanged = Signal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._color = ""
        self.clicked.connect(self._choose_color)
        self._refresh()

    def color(self) -> str:
        return self._color

    def set_color(self, value: object) -> None:
        text = str(value or "").strip()
        color = QColor(text)
        self._color = color.name(QColor.NameFormat.HexArgb if color.alpha() < 255 else QColor.NameFormat.HexRgb) if color.isValid() else ""
        self._refresh()

    def _refresh(self) -> None:
        self.setIcon(color_preview_icon(self._color))
        self.setText(self._color or "Default")
        self.setToolTip("Choose colour" if self._color else "Choose colour (currently default)")

    def _choose_color(self) -> None:
        initial = QColor(self._color) if self._color else QColor("#1f77b4")
        dialog = QColorDialog(initial, self)
        dialog.setOption(QColorDialog.ColorDialogOption.ShowAlphaChannel, True)
        if dialog.exec() == QColorDialog.DialogCode.Accepted:
            self.set_color(dialog.selectedColor().name(QColor.NameFormat.HexArgb))
            self.colorChanged.emit(self._color)
