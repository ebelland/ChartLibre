"""Property editor for the series of the selected axis.

Handles per-series style (colour, marker, line style, alpha, visibility, legend
participation), ordering, deletion, and the series SQL query.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Any

from PySide6.QtCore import QPointF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QIcon, QPainter, QPen, QTextOption
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFrame,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QPlainTextEdit,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from matplotlib import rcParams

from app.charts.kwarg_spec import DEFAULT
from app.styles.style import (
    MARGIN_PANEL,
    TitledCard,
    create_action_button,
    create_hidpi_pixmap,
    stdSizeAndlayout,
)
from app.widgets.chart_properties.base_properties import BaseProperties
from app.widgets.drop_down_controls.color_combo import DEFAULT_COLOR_LABEL, MatplotlibColorCombo
from app.widgets.drop_down_controls.line_combo import LineStyleCombo
from app.widgets.drop_down_controls.marker_combo import MarkerStyleCombo
from app.logs.logger import applogger
from app.utils.config import get_constant
from app.utils.i18n import _
from app.utils.messages import ask


AxisDescriptorLike = Any
SeriesDescriptorLike = Any

SQL_QUERY_VISIBLE_LINES = get_constant("sql_query_visible_lines", 6)

_SWATCH_W, _SWATCH_H = 28, 14

#: Matplotlib linestyle code -> Qt pen style, same mapping LineStyleCombo
#: uses. Anything not in here (an unrecognised code, "none") falls back to
#: a plain solid line - "none" is handled separately, as a dot.
_SWATCH_PEN_STYLES: dict[str, Qt.PenStyle] = {
    "-": Qt.PenStyle.SolidLine,
    "--": Qt.PenStyle.DashLine,
    "-.": Qt.PenStyle.DashDotLine,
    ":": Qt.PenStyle.DotLine,
}


@lru_cache(maxsize=None)
def _series_swatch_icon(color: str, linestyle: str) -> QIcon:
    """A small colour/line-style preview for one row of the series combo.

    Best-effort, not a render: an explicit colour and linestyle are drawn
    exactly, but a series left on "whatever the cycle/style sheet decides"
    is approximated by the caller (the active property cycle, indexed by
    the series' position in the combo) rather than replicated stroke for
    stroke - the renderer that actually draws the chart may cycle
    differently per chart type. Enough to recognise "this is the blue
    dashed one" without opening the series first, which is the point.
    """
    pixmap = create_hidpi_pixmap(_SWATCH_W, _SWATCH_H)
    qcolor = QColor(color)
    if not qcolor.isValid():
        qcolor = QColor("#808080")

    painter = QPainter(pixmap)
    try:
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        mid_y = _SWATCH_H / 2

        if linestyle == "none":
            # Marker-only series: a dot reads as "no line" better than an
            # empty icon, which looks like the swatch failed to draw.
            painter.setBrush(QBrush(qcolor))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(QPointF(_SWATCH_W / 2, mid_y), 3, 3)
        else:
            pen = QPen(qcolor)
            pen.setWidth(2)
            pen.setStyle(_SWATCH_PEN_STYLES.get(linestyle, Qt.PenStyle.SolidLine))
            painter.setPen(pen)
            painter.drawLine(QPointF(2, mid_y), QPointF(_SWATCH_W - 2, mid_y))
    finally:
        painter.end()

    return QIcon(pixmap)


class SeriesPropertiesWidget(BaseProperties):
    """Compact editor for series descriptor style/options."""

    series_selected = Signal(int)
    series_options_requested = Signal(dict)
    series_order_requested = Signal(list)
    series_delete_requested = Signal(int)

    # Fixed height, in visible lines, for the SQL query editor. A fixed
    # size rather than Expanding keeps the form layout stable regardless
    # of query length and avoids the editor growing to swallow the panel.

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)

        # _repo/_figure_id/_figure/_redraw_callback come from BaseProperties.
        self._current_axis_id: int | None = None
        self._current_series_id: int | None = None
        self._series_map: dict[int, SeriesDescriptorLike] = {}
        #: key -> (stored value, combo index it was loaded as); see _load_choice.
        self._stored_choices: dict[str, tuple[Any, int]] = {}

        self._build_ui()
        self._install_auto_apply(self._emit_series_options_requested)
        self._connect_auto_apply()
        self.clear_connected_figure()

    def _connect_auto_apply(self) -> None:
        """Apply a style edit a short moment after the last control change.

        ``_series_combo`` is left out: it picks which series is shown, not
        an edit to one, and its handler repopulates the form under the
        reload guard anyway.
        """
        self._watch(
            self._legend_label_edit,
            self._sql_query_edit,
            self._visible_check,
            self._show_in_legend_check,
            self._sort_x_check,
            self._linestyle_combo,
            self._marker_combo,
            self._markersize_spin,
            self._color_combo,
        )

    def _build_ui(self) -> None:
        """Build all UI sections inside a resizable scrollable container.

        The selector card stays at natural height. The options card receives
        the remaining vertical space while still allowing the whole panel to
        scroll when the host becomes too small.
        """
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding,
        )

        content = QWidget(self)
        content.setProperty("toolboxPage", True)
        content.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        content.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding,
        )

        root = QVBoxLayout(content)
        root.setContentsMargins(*MARGIN_PANEL)
        root.setSpacing(12)

        self._selector_section = self._build_selector_section()
        root.addWidget(self._selector_section, 0)

        self._options_section = self._build_options_section()
        self._options_section.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        self._options_section.title_label.setSizePolicy(
            QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed
        )
        self._options_section.card.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        root.addWidget(self._options_section, 1)

        scroll = QScrollArea(self)
        scroll.setProperty("toolboxPage", True)
        scroll.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        scroll.viewport().setProperty("toolboxPage", True)
        scroll.viewport().setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding,
        )
        scroll.setWidget(content)

        main = QVBoxLayout(self)
        stdSizeAndlayout(main)
        main.addWidget(scroll, 1)

    def _build_selector_section(self) -> QWidget:
        """Create the series selector and ordering controls."""
        section = TitledCard(self, _("Axis"), "seriesSelectorCard")
        section.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Preferred,
        )
        self._series_title = section.title_label

        layout = section.card.layout()

        self._series_combo = QComboBox(section)
        stdSizeAndlayout(self._series_combo)
        self._series_combo.currentIndexChanged.connect(
            self._on_series_combo_changed
        )
        layout.addWidget(self._series_combo)

        row = QWidget(section)
        row_layout = QHBoxLayout(row)
        stdSizeAndlayout(row_layout)

        self._btn_move_up = create_action_button(
            parent=row,
            action_id="up",
            action=self._move_current_series_up,
            layout=row_layout,
        )
        self._btn_move_down = create_action_button(
            parent=row,
            action_id="down",
            action=self._move_current_series_down,
            layout=row_layout,
        )
        self._btn_delete = create_action_button(
            parent=row,
            action_id="delete",
            action=self._on_delete_clicked,
            layout=row_layout,
        )
        # No Apply button: every style control applies itself a short moment
        # after it changes (see _connect_auto_apply). Up / Down / Delete stay
        # - they reorder and remove series, not commit the form.

        row_layout.addStretch(1)
        layout.addWidget(row)

        return section

    def _build_options_section(self) -> QWidget:
        """Create editable series style controls."""
        section = TitledCard(self, _("Properties"), "seriesOptionsCard")
        stdSizeAndlayout(section)
        section.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding,
        )


        form = QFormLayout()
        stdSizeAndlayout(form)

        self._legend_label_edit = QLineEdit(section)
        stdSizeAndlayout(self._legend_label_edit)

        self._sql_query_edit = QPlainTextEdit(
            section,
            readOnly=False,
            placeholderText="Enter SQL query for this series.",
            undoRedoEnabled=True,
        )
        self._sql_query_edit.setLineWrapMode(
            QPlainTextEdit.LineWrapMode.WidgetWidth
        )
        self._sql_query_edit.setWordWrapMode(
            QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere
        )
        self._sql_query_edit.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        stdSizeAndlayout(self._sql_query_edit)
        self._sql_query_edit.setFixedHeight(
            self._sql_query_edit.fontMetrics().lineSpacing()
            * SQL_QUERY_VISIBLE_LINES
            + 12
        )

        self._visible_check = QCheckBox(_("Visible"), section)
        self._show_in_legend_check = QCheckBox(_("Show in legend"), section)
        self._sort_x_check = QCheckBox(_("Sort by X ascending"), section)

        stdSizeAndlayout(self._visible_check)
        stdSizeAndlayout(self._show_in_legend_check)
        stdSizeAndlayout(self._sort_x_check)

        flags_row = QWidget(section)
        stdSizeAndlayout(flags_row)

        flags_layout = QHBoxLayout(flags_row)
        stdSizeAndlayout(flags_layout)
        flags_layout.addWidget(self._visible_check, 0)
        flags_layout.addWidget(self._show_in_legend_check, 0)
        flags_layout.addStretch(1)

        self._linestyle_combo = LineStyleCombo(section)
        self._marker_combo = MarkerStyleCombo(section)
        # Points, as Matplotlib's markersize. The minimum shows as "Default"
        # and is stored as no value at all: a spin box cannot be empty, and a
        # size of 0 would hide the markers rather than leave them to the style.
        self._markersize_spin = QDoubleSpinBox(section)
        self._markersize_spin.setRange(0.0, 1000.0)
        self._markersize_spin.setDecimals(1)
        self._markersize_spin.setSingleStep(0.5)
        self._markersize_spin.setSpecialValueText(_("Default"))
        self._markersize_spin.setToolTip(_("Marker size in points. Default leaves it to the style."))
        # "Default", not "(none)": an empty colour is not "this series has
        # no colour", it is "let the style sheet's cycle pick one" - which
        # is what the renderer does with it, and what the Line style and
        # Marker combos next to it already call their own first entry.
        self._color_combo = MatplotlibColorCombo(
            section,
            include_none=True,
            none_label=DEFAULT_COLOR_LABEL,
        )

        stdSizeAndlayout(self._linestyle_combo, minimum_contents_length=0)
        stdSizeAndlayout(self._marker_combo, minimum_contents_length=0)
        stdSizeAndlayout(self._color_combo, minimum_contents_length=0)

        form.addRow(_("Legend label"), self._legend_label_edit)
        form.addRow(_("SQL query"), self._sql_query_edit)
        form.addRow(_("Visibility"), flags_row)
        form.addRow(_("Sort"), self._sort_x_check)
        form.addRow(_("Line style"), self._linestyle_combo)
        form.addRow(_("Marker"), self._marker_combo)
        form.addRow(_("Marker size"), self._markersize_spin)
        form.addRow(_("Color"), self._color_combo)

        raw_layout = section.card.layout()
        if not isinstance(raw_layout, QVBoxLayout):
            raise RuntimeError("TitledCard did not create a vertical box layout")

        raw_layout.addLayout(form, 0)

        # Important:
        # If you have self.series_list in your real code, add it here,
        # outside the QFormLayout, with stretch 1.
        #
        # self.series_list.setMinimumHeight(0)
        # self.series_list.setMaximumHeight(16777215)
        # self.series_list.setSizePolicy(
        #     QSizePolicy.Policy.Expanding,
        #     QSizePolicy.Policy.Expanding,
        # )
        # layout.addWidget(self.series_list, 1)

        return section

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    # set_connected_figure is BaseProperties': attach the four attributes,
    # then call _reload_from_descriptor() below, which already ends by
    # enabling or disabling this editor's own controls itself.

    def clear_connected_figure(self) -> None:
        """Reset UI and disable editing."""
        self._current_axis_id = None
        self._current_series_id = None
        self._series_map.clear()
        self._series_title.setText(_("Axis: No axis selected"))
        self._clear_series_combo()
        self._clear_series_fields()
        super().clear_connected_figure()

    def set_current_axis_id(self, axis_id: int | None) -> None:
        """Limit the series selector to one axis."""
        self._current_axis_id = int(axis_id) if axis_id is not None else None
        if self._repo is not None and self._figure_id is not None:
            self.reload_controls()

    def current_axis_id(self) -> int | None:
        """Return the current axis id filter."""
        return self._current_axis_id

    def select_series_named(self, name: str) -> bool:
        """Show the series called *name* on the current axis (a click on it in the chart).

        The chart labels a series' artists with its name - or a name it
        starts with, for a series split by a group column or given a
        companion line ("name (rolling)") - so an exact match wins, then
        the longest name the label starts with.
        """
        matches = [
            (len(str(desc.name)), series_id)
            for series_id, desc in self._series_map.items()
            if name == str(desc.name) or name.startswith(str(desc.name))
        ]
        if not matches:
            return False
        exact = [series_id for series_id, desc in self._series_map.items() if name == str(desc.name)]
        self._select_series(exact[0] if exact else max(matches)[1])
        return True

    # ------------------------------------------------------------------
    # Descriptor loading
    # ------------------------------------------------------------------

    def _reload_from_descriptor(self) -> None:
        """Reload the series selector from the connected figure descriptor.

        This is the single descriptor reload path for the series panel. It is
        safe during shutdown, chart deletion, stale selection changes, and
        descriptor schema errors.
        """
        if self._repo is None or self._figure_id is None:
            self.clear_connected_figure()
            return

        descriptor = self._repo.load_figure_descriptor(self._figure_id)
        previous_series_id = self._current_series_id

        self._series_map.clear()
        self._series_combo.blockSignals(True)
        try:
            self._series_combo.clear()

            if descriptor is None:
                applogger.warning(
                    "No figure descriptor found for figure_id=%s. "
                    "Series editing disabled for this figure.",
                    self._figure_id,
                )
                return

            for axis_desc in self._axes_from_descriptor(descriptor):
                self._add_axis_series(axis_desc)
        finally:
            self._series_combo.blockSignals(False)

        self._update_title()

        if self._series_combo.count() == 0:
            self._load_series_descriptor(None)
            self._set_enabled_state(False)
            return

        self._set_enabled_state(True)
        self._select_series(previous_series_id)

    def _axes_from_descriptor(self, descriptor: Any) -> list:
        """Return axes from a validated descriptor."""
        axes = getattr(descriptor, "axes", None)
        if axes is None:
            applogger.error(
                "Figure descriptor id=%r has no axes list. "
                "Series editing stopped; please check the descriptor schema.",
                getattr(descriptor, "id", self._figure_id),
            )
            return []
        return list(axes)

    def _add_axis_series(self, axis_desc: AxisDescriptorLike) -> None:
        """Add all series for the axis when it passes the current filter."""
        axis_id = int(axis_desc.id)

        if self._current_axis_id is not None and axis_id != self._current_axis_id:
            return

        for series_desc in list(axis_desc.series or []):
            series_id = int(series_desc.id)
            self._series_map[series_id] = series_desc
            self._series_combo.addItem(
                self._series_swatch_icon_for(series_desc),
                self._series_display_label(series_desc),
                series_id,
            )

    def _series_swatch_icon_for(self, series_desc: SeriesDescriptorLike) -> QIcon:
        """Resolve the colour/linestyle swatch icon for one combo row."""
        style = self._series_style(series_desc)

        color = str(style.get("color", "") or "").strip()
        if not color:
            try:
                cycle = rcParams["axes.prop_cycle"].by_key().get("color") or []
            except (KeyError, AttributeError, TypeError):
                cycle = []
            cycle = list(cycle) or ["#1f77b4"]
            # The combo is built in display order, so its current item
            # count is this series' position in it - the same index the
            # renderer's own cycle would be at if nothing else on this axis
            # set an explicit colour either.
            color = str(cycle[self._series_combo.count() % len(cycle)])

        linestyle = str(style.get("linestyle", "") or "").strip().lower()
        if linestyle in ("", DEFAULT):
            linestyle = "-"

        return _series_swatch_icon(color, linestyle)

    def _select_series(self, preferred_series_id: int | None) -> None:
        """Select the previous series when possible, otherwise first."""
        index_to_select = 0

        if preferred_series_id is not None:
            for index in range(self._series_combo.count()):
                data = self._series_combo.itemData(index)
                if data is not None and int(data) == preferred_series_id:
                    index_to_select = index
                    break

        self._series_combo.setCurrentIndex(index_to_select)
        self._on_series_combo_changed(index_to_select)

    def _update_title(self) -> None:
        """Name the axis whose series are being edited."""
        if self._current_axis_id is None:
            self._series_title.setText(_("Axis: No axis selected"))
            return
        name = ""
        if self._repo is not None and self._figure_id is not None:
            try:
                for axis_id, _index, title in self._repo.list_axes_for_figure(int(self._figure_id)):
                    if int(axis_id) == self._current_axis_id:
                        name = str(title or "").strip()
                        break
            except Exception:
                applogger.debug("Could not resolve the series axis title.", exc_info=True)
        name = name or _("Axis {id}").format(id=self._current_axis_id)
        self._series_title.setText(_("Axis: {name}").format(name=name))

    # ------------------------------------------------------------------
    # Series binding
    # ------------------------------------------------------------------

    def _series_style(self, series_desc: SeriesDescriptorLike) -> dict[str, Any]:
        """Return a mutable series style dictionary."""
        if series_desc.options is None:
            return {}

        if isinstance(series_desc.options, dict):
            return dict(series_desc.options)

        applogger.error(
            f"Series id={series_desc.id!r} has invalid style. Editing stopped; "
            "please check the descriptor schema."
        )
        return {}

    def _series_display_label(self, series_desc: SeriesDescriptorLike) -> str:
        """Build selector text for one series."""
        style = self._series_style(series_desc)
        name = str(
            series_desc.name
            or style.get("label")
            or f"Series {series_desc.id}"
        ).strip()

        return name if bool(style.get("visible", True)) else f"{name} (hidden)"

    def _load_series_descriptor(
        self,
        series_desc: SeriesDescriptorLike | None,
    ) -> None:
        """Load one series descriptor into the form."""
        if series_desc is None:
            self._clear_series_fields()
            return

        with self._reloading_controls():
            self._current_series_id = int(series_desc.id)
            style = self._series_style(series_desc)

            self._legend_label_edit.setText(str(style.get("label", "") or ""))
            self._sql_query_edit.setPlainText(
                str(getattr(series_desc, "sql_query", "") or "")
            )
            self._visible_check.setChecked(bool(style.get("visible", True)))
            self._show_in_legend_check.setChecked(
                bool(style.get("show_in_legend", True))
            )
            self._sort_x_check.setChecked(bool(style.get("sort_x", False)))

            self._load_choice(self._linestyle_combo, "linestyle", style.get("linestyle", DEFAULT), none="none")
            self._load_choice(self._marker_combo, "marker", style.get("marker", DEFAULT), none="")
            try:
                markersize = float(style.get("markersize") or 0.0)
            except (TypeError, ValueError):
                markersize = 0.0
            self._markersize_spin.setValue(max(markersize, 0.0))
            raw_color = style.get("color", "")
            self._set_color_value(str(raw_color or ""))
            self._stored_choices["color"] = (raw_color, self._color_combo.currentIndex())

    def _load_choice(self, combo: QComboBox, key: str, raw: Any, *, none: str) -> None:
        """Select what a stored line style / marker shows as, remembering the stored value.

        A stored style is what the series *has*, the combo only what it can
        show: "", "None" and an explicit no-line / no-marker all read as the
        combo's None entry (*none*), and a value the combo has no entry for
        (a dash pattern, "dashed") shows as Default. Writing the combo's
        reading back on the next edit of any other field changed the series -
        a chosen None became Default, a custom dash a solid line - so the
        stored value is kept, and sent back for as long as the combo is left
        on what it was loaded as.
        """
        text = raw.strip() if isinstance(raw, str) else None
        if text is not None and text.lower() == "none":
            text = none
        index = combo.findData(text) if text is not None else -1
        combo.setCurrentIndex(index if index >= 0 else 0)
        self._stored_choices[key] = (raw, combo.currentIndex())

    def _choice(self, combo: QComboBox, key: str, fallback: str) -> Any:
        """The value to store for *combo*: the loaded one while it is untouched."""
        stored = self._stored_choices.get(key)
        if stored is not None and combo.currentIndex() == stored[1]:
            return stored[0]
        return str(combo.currentData() or fallback)

    def _choice_color(self) -> Any:
        stored = self._stored_choices.get("color")
        if stored is not None and self._color_combo.currentIndex() == stored[1]:
            return stored[0] if stored[0] is not None else ""
        return self._color_combo.current_hex().strip()

    def _clear_series_fields(self) -> None:
        """Clear form fields for the no-selection state."""
        self._stored_choices.clear()
        with self._reloading_controls():
            self._current_series_id = None
            self._legend_label_edit.clear()
            self._sql_query_edit.clear()
            self._visible_check.setChecked(True)
            self._show_in_legend_check.setChecked(True)
            self._sort_x_check.setChecked(False)
            self._linestyle_combo.setCurrentIndex(0)
            self._marker_combo.setCurrentIndex(0)
            self._markersize_spin.setValue(0.0)
            self._color_combo.setCurrentIndex(0)

    def _set_color_value(self, value: str) -> None:
        """Select a color by hex value or Matplotlib color name."""
        matched = False

        if value:
            matched = self._color_combo.set_current_hex(value)
            if not matched:
                matched = self._color_combo.set_current_name(value)

        if not matched:
            self._color_combo.setCurrentIndex(0)

    def _set_combo_value(self, combo: QComboBox, value: str) -> None:
        """Set combo data when present, otherwise select the first item."""
        index = combo.findData(value)
        combo.setCurrentIndex(index if index >= 0 else 0)

    # ------------------------------------------------------------------
    # Events and actions
    # ------------------------------------------------------------------

    def _clear_series_combo(self) -> None:
        """Clear the selector without emitting selection-change signals."""
        self._series_combo.blockSignals(True)
        self._series_combo.clear()
        self._series_combo.blockSignals(False)

    def _set_enabled_state(self, enabled: bool) -> None:
        """Enable or disable interactive controls."""
        for widget in (
            self._series_combo,
            self._btn_move_up,
            self._btn_move_down,
            self._btn_delete,
            self._legend_label_edit,
            self._sql_query_edit,
            self._visible_check,
            self._show_in_legend_check,
            self._sort_x_check,
            self._linestyle_combo,
            self._marker_combo,
            self._markersize_spin,
            self._color_combo,
        ):
            widget.setEnabled(enabled)

    def _on_series_combo_changed(self, index: int) -> None:
        """Handle series selector changes."""
        if index < 0:
            self._load_series_descriptor(None)
            return

        data = self._series_combo.itemData(index)
        if data is None:
            self._load_series_descriptor(None)
            return

        series_id = int(data)
        series_desc = self._series_map.get(series_id)

        if series_desc is None:
            applogger.error(
                "Series descriptor id=%r not found in the map. "
                "Editing stopped; please check the descriptor.",
                series_id,
            )
            self._load_series_descriptor(None)
            return

        self._load_series_descriptor(series_desc)
        self.series_selected.emit(series_id)

    def _on_delete_clicked(self) -> None:
        """Delete the selected series."""
        index = self._series_combo.currentIndex()
        if index < 0:
            return

        data = self._series_combo.itemData(index)
        if data is None:
            return

        series_id = int(data)

        if not ask(
            self,
            "series.confirm_delete",
            series=self._series_combo.itemText(index),
        ):
            return

        if series_id in self._series_map:
            del self._series_map[series_id]

        self._series_combo.removeItem(index)
        self.series_delete_requested.emit(int(series_id))

    def _move_current_series_up(self) -> None:
        """Move the selected series up in combo order."""
        self._move_current_series(-1)

    def _move_current_series_down(self) -> None:
        """Move the selected series down in combo order."""
        self._move_current_series(1)

    def _move_current_series(self, offset: int) -> None:
        """Move the selected series by one row and emit the new order."""
        index = self._series_combo.currentIndex()
        target = index + offset

        if index < 0 or target < 0 or target >= self._series_combo.count():
            return

        text = self._series_combo.itemText(index)
        data = self._series_combo.itemData(index)

        self._series_combo.removeItem(index)
        self._series_combo.insertItem(target, text, data)
        self._series_combo.setCurrentIndex(target)

        self._emit_series_order_requested()

    def _emit_series_order_requested(self) -> None:
        """Emit the current combo order."""
        ordered_ids: list[int] = []

        for index in range(self._series_combo.count()):
            data = self._series_combo.itemData(index)
            if data is not None:
                ordered_ids.append(int(data))

        self.series_order_requested.emit(ordered_ids)

    def _emit_series_options_requested(self) -> None:
        """Emit the current form payload."""
        self.series_options_requested.emit(
            {
                "series_id": self._current_series_id,
                "label": self._legend_label_edit.text().strip(),
                "sql_query": self._sql_query_edit.toPlainText().strip(),
                "visible": bool(self._visible_check.isChecked()),
                "show_in_legend": bool(self._show_in_legend_check.isChecked()),
                "sort_x": bool(self._sort_x_check.isChecked()),
                "linestyle": self._choice(self._linestyle_combo, "linestyle", "-"),
                "marker": self._choice(self._marker_combo, "marker", ""),
                # None removes the key: the minimum means "leave it to the style".
                "markersize": self._markersize_spin.value() or None,
                # What the series has, while the combo is left as loaded: it
                # has no entry for "C0", "0.5" or a colour with alpha, and
                # would otherwise write "" over them on any other edit.
                "color": self._choice_color(),
            }
        )