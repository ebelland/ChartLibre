"""Dialog for importing CSV/Excel files into database tables.

Handles source selection, read options (delimiter, encoding, header, skipped
rows), per-column type overrides, and a live preview of the resulting table.
The import itself is delegated to ``app.utils.import_runner`` so that a saved
link can later be refreshed through exactly the same code path.
"""
from __future__ import annotations

import re

from dataclasses import dataclass
from pathlib import Path
from collections.abc import Callable

import pandas as pd
from PySide6.QtCore import QAbstractTableModel, QModelIndex, QPersistentModelIndex, Qt, QTimer
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QBoxLayout,
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QMenu,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from app.utils.config import get_import_data_dialog_config, set_import_data_dialog_config
from app.data.sqlite_repo import SqliteRepo
from app.widgets.table_preview import TablePreviewPanel
from app.logs.logger import applogger
from app.utils.messages import show_message
from app.styles.style import (
    action_presentation,
    create_action_button,
    load_icon,
    mark_editor_panel,
    mark_icon_only,
    stdSizeAndlayout,
    TitledCard,
)
from app.utils.i18n import _
from app.dialogs.two_panels_dialog_base import PanelDialog, SettingsTableDialog


# -----------------------------------------------------------------------------
# Reading helpers
#
# The actual reading of files and URLs lives in app.utils.data_sources
# URL - lives in app.utils.data_sources, which has no Qt import: it is what
# app.utils.import_runner.refresh_link calls into headlessly for "Update
# link", and this dialog calls into live for the preview.  Imported here
# (rather than qualified as data_sources.whatever at each call site) so that
# existing external imports of these names from this module - the test suite
# and app.main_window.main_window - keep working unchanged.
# -----------------------------------------------------------------------------
from app.utils.data_sources import (
    CLIPBOARD_SOURCE_NAME,
    IMPORT_FILE_FILTER,
    WebDataSource,
    add_user_web_source,
    filename_from_url,
    is_valid_web_url,
    load_web_data_sources,
    read_any_file,
    read_clipboard_text,
    transpose_delimited_text,
    read_web_url,
    remove_user_web_source,
)
from app.utils.coercion import to_numbers


#: The curated "Web source" quick-pick catalogue - see
#: web_sources.json (in the ChartLibre folder) for the actual entries and
#: app.utils.data_sources.WebDataSource for the shape of one.  Kept as a
#: module-level name here too since the test suite and (previously) this
#: dialog both import it from this module.


# -----------------------------------------------------------------------------
# Preview model
# -----------------------------------------------------------------------------


class DataFramePreviewModel(QAbstractTableModel):
    """Lightweight preview model for DataFrames."""

    def __init__(self, df: pd.DataFrame, *, max_rows: int = 500, max_cols: int = 200, parent=None) -> None:
        super().__init__(parent)
        self._df = df
        self._cols = list(df.columns)[:max_cols]
        self._nrows = min(len(df), max_rows)

    def rowCount(self, parent: QModelIndex|QPersistentModelIndex = QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else self._nrows

    def columnCount(self, parent: QModelIndex|QPersistentModelIndex = QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._cols)

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole):  # noqa: N802
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == Qt.Orientation.Horizontal:
            return str(self._cols[section]) if 0 <= section < len(self._cols) else None
        return str(section + 1)

    def data(self, index: QModelIndex|QPersistentModelIndex, role: int = Qt.ItemDataRole.DisplayRole):  # noqa: N802
        if not index.isValid() or role != Qt.ItemDataRole.DisplayRole:
            return None
        r = index.row()
        c = index.column()
        if r >= self._nrows or c >= len(self._cols):
            return None
        col = self._cols[c]
        val = self._df.iloc[r][col]
        return "" if pd.isna(val) else str(val)


class _AddWebSourceDialog(PanelDialog):
    """Collects a name, a URL and an optional note for one quick-pick entry.

    Small enough, and specific enough to this one caller, to live next to
    ``ImportDataDialog`` rather than in its own module - the same reasoning
    ``DataFramePreviewModel`` above already follows.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent, title=_("Add source"), size="small")
        self.name = ""
        self.url = ""
        self.description = ""

        form = QFormLayout()
        stdSizeAndlayout(form)
        self.add_card(_("Web source"), "addWebSourceCard").layout().addLayout(form)

        self._name_field = QLineEdit(self)
        stdSizeAndlayout(self._name_field)
        form.addRow(_("Name"), self._name_field)

        self._url_field = QLineEdit(self)
        self._url_field.setPlaceholderText(_("https://example.com/data.csv"))
        stdSizeAndlayout(self._url_field)
        form.addRow(_("URL"), self._url_field)

        self._description_field = QLineEdit(self)
        stdSizeAndlayout(self._description_field)
        form.addRow(_("Description"), self._description_field)

        self.body_layout.addStretch(1)
        self.add_action("apply", self._on_accept)
        self.add_action("close", self.reject)

    def _on_accept(self) -> None:
        name = self._name_field.text().strip()
        url = self._url_field.text().strip()
        if not name or not url:
            show_message(self, "import.web_source_incomplete")
            return
        if not is_valid_web_url(url):
            show_message(self, "import.web_invalid_url")
            return
        self.name = name
        self.url = url
        self.description = self._description_field.text().strip()
        self.accept()


# -----------------------------------------------------------------------------
# Import dialog
# -----------------------------------------------------------------------------


@dataclass(slots=True)
class ImportResult:
    table_name: str
    rows: int
    cols: int


class ImportDataDialog(SettingsTableDialog):
    """Import data from files or clipboard into the current SQLite database."""

    SQLITE_TYPES = [
        "Ignore",
        "INTEGER",
        "REAL",
        "TEXT",
        "BLOB",
        "NUMERIC",
        "DATE",
        "TIME",
        "DATETIME",
    ]

    ENCODINGS = [
        "auto",
        "utf-8",
        "utf-8-sig",
        "cp1252",
        "latin-1",
        "utf-16",
    ]

    def __init__(self, repo: SqliteRepo, parent: QWidget | None = None) -> None:
        super().__init__(
            parent,
            title=_("Import data"),
            icon=load_icon("import"),
            settings_title=_("Settings"),
            content_title=_("Preview"),
            settings_width=420,
        )
        self._repo = repo
        self.import_result: ImportResult | None = None
        self._df: pd.DataFrame | None = None

        # Which of the sources the preview and the import read from. Every
        # path that sets one must clear the others, or the dialog shows one
        # source's data under another's name - which is exactly what pasting
        # after opening a file used to do.
        self._source_mode: str = "none"  # none|file|clipboard|web
        self._clipboard_text: str = ""
        #: The clipboard is read with rows and columns swapped.
        self._clipboard_transposed: bool = False
        self._path: str = ""
        self._last_auto_table: str = ""
        self._picked_web_source: WebDataSource | None = None

        # Size and root padding come from the shared dialog shell.

        cfg = get_import_data_dialog_config()
        self._desired_sheet = str(cfg.get("sheet", "") or "").strip()

        # ---------------- Left panel ----------------
        # The side panels' own layout: a title above each card (TitledCard),
        # not inside it, and each row short enough for the panel's width -
        # a row of five controls ran off the right edge and was cut off,
        # since the panel does not scroll sideways.
        left = QWidget(self.settings_frame)
        left_layout = QVBoxLayout(left)
        stdSizeAndlayout(left_layout)

        # -- Source: a file, the clipboard; Excel's sheet.
        source = TitledCard(left, _("Source"), "importSourceCard")
        source_layout = source.card.layout()
        src_row = QHBoxLayout()
        stdSizeAndlayout(src_row)
        # Named for the source rather than the verb:
        # "Open" and "Paste" indicate where the data comes from.
        create_action_button(
            parent=source.card, action_id="open", action=self._on_browse, layout=src_row,
            presentation=(
                action_presentation("open")[0], _("File"),
                _("Import a file: CSV or other delimited text, Excel, JSON"),
            ),
        )
        create_action_button(
            parent=source.card, action_id="paste", action=self._on_load_clipboard, layout=src_row,
            presentation=(
                action_presentation("paste")[0], _("Clipboard"),
                _("Import the table on the clipboard"),
            ),
        )
        create_action_button(
            parent=source.card, action_id="paste_transposed",
            action=lambda: self._on_load_clipboard(transposed=True), layout=src_row,
            presentation=(
                action_presentation("paste")[0], _("Clipboard transposed"),
                _("Import the table on the clipboard with rows and columns swapped - "
                  "for data copied one series per row"),
            ),
        )
        src_row.addStretch(1)
        source_layout.addLayout(src_row)

        # Excel worksheet selector (shown only for Excel files)
        form = QFormLayout()
        stdSizeAndlayout(form)
        self._sheet = QComboBox(source.card)
        self._sheet.setEnabled(False)
        self._sheet.setVisible(False)
        self._sheet.setToolTip(_("Worksheet (for Excel sources)"))
        stdSizeAndlayout(self._sheet)
        form.addRow(_("Sheet"), self._sheet)
        self._sheet_label = form.labelForField(self._sheet)
        if self._sheet_label is not None:
            self._sheet_label.setVisible(False)
        source_layout.addLayout(form)
        left_layout.addWidget(source)

        # -- Web: a quick-pick source or an address, then Fetch.
        web = TitledCard(left, _("Web"), "importWebCard")
        web_layout = web.card.layout()
        pick_row = QHBoxLayout()
        stdSizeAndlayout(pick_row)
        # A push button with a menu, not a combo: QMenu.addSection groups the
        # catalogue by category, and the list is not held to a combo popup's
        # fixed height.
        self._web_source_button = create_action_button(
            parent=web.card, action_id="web_sources", action=None, layout=pick_row
        )
        self._web_source_button.setEnabled(True)
        self._web_source_menu = QMenu(self._web_source_button)
        self._web_source_button.setMenu(self._web_source_menu)
        self._rebuild_web_source_menu()
        pick_row.addStretch(1)
        self._btn_add_web_source = create_action_button(
            parent=web.card, action_id="web_source_add", action=self._on_add_web_source, layout=pick_row
        )
        mark_icon_only(self._btn_add_web_source)
        self._btn_delete_web_source = create_action_button(
            parent=web.card,
            action_id="web_source_delete",
            action=self._on_delete_web_source,
            layout=pick_row,
        )
        mark_icon_only(self._btn_delete_web_source)
        self._btn_delete_web_source.setEnabled(False)
        web_layout.addLayout(pick_row)

        url_row = QHBoxLayout()
        stdSizeAndlayout(url_row)
        self._url = QLineEdit(web.card)
        self._url.setPlaceholderText(_("https://example.com/data.csv"))
        stdSizeAndlayout(self._url)
        url_row.addWidget(self._url, 1)
        create_action_button(
            parent=web.card, action_id="fetch_url", action=self._on_fetch_url, layout=url_row
        )
        web_layout.addLayout(url_row)
        left_layout.addWidget(web)

        # -- Read options
        read = TitledCard(left, _("Read options"), "importReadCard")
        options_form = QFormLayout()
        stdSizeAndlayout(options_form)

        self._table = QLineEdit(read.card)
        self._table.setText(str(cfg.get("table", "")))
        stdSizeAndlayout(self._table)
        options_form.addRow(_("Table"), self._table)

        self._has_header = QCheckBox(_("First row is header"), read.card)
        self._has_header.setChecked(bool(cfg.get("header", True)))
        options_form.addRow("", self._has_header)

        self._skip_rows = QSpinBox(read.card)
        self._skip_rows.setRange(0, 1_000_000)
        self._skip_rows.setValue(int(cfg.get("skip_rows", 0) or 0))
        self._skip_rows.setKeyboardTracking(False)
        self._skip_rows.setAccelerated(True)
        options_form.addRow(_("Skip top rows"), self._skip_rows)

        self._skip_last = QSpinBox(read.card)
        self._skip_last.setRange(0, 1_000_000)
        self._skip_last.setValue(int(cfg.get("skip_last", 0) or 0))
        self._skip_last.setKeyboardTracking(False)
        self._skip_last.setAccelerated(True)
        options_form.addRow(_("Skip last rows"), self._skip_last)

        # Delimiter dropdown (editable)
        self._delim = QComboBox(read.card)
        self._delim.setEditable(True)
        self._delim.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        self._delim.addItem(_("auto"), userData=None)
        self._delim.addItem(",", userData=",")
        self._delim.addItem(";", userData=";")
        # The escape sequence itself, which reads the same in every language.
        self._delim.addItem("\\t", userData="\t")
        self._delim.addItem("|", userData="|")
        self._delim.addItem(_("space"), userData=" ")
        saved_delim = (cfg.get("delim", "") or "").strip()
        self._delim.setCurrentIndex(0)
        if saved_delim:
            self._delim.setEditText(saved_delim)
        stdSizeAndlayout(self._delim)
        options_form.addRow(_("Delimiter"), self._delim)

        # Encoding dropdown (editable)
        self._encoding = QComboBox(read.card)
        self._encoding.setEditable(True)
        self._encoding.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        for e in self.ENCODINGS:
            self._encoding.addItem(e)
        saved_enc = (cfg.get("encoding", "auto") or "auto").strip() or "auto"
        self._encoding.setCurrentText(saved_enc)
        stdSizeAndlayout(self._encoding)
        options_form.addRow(_("Encoding"), self._encoding)

        read.card.layout().addLayout(options_form)
        left_layout.addWidget(read)

        # -- Columns: what the preview found, and the type each will get.
        columns = TitledCard(left, _("Columns"), "importColumnsCard")
        self._col_table = QTableWidget(columns.card)
        self._col_table.setColumnCount(2)
        self._col_table.setHorizontalHeaderLabels([_("Column"), _("Type")])
        self._col_table.verticalHeader().setVisible(False)
        self._col_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self._col_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self._col_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._col_table.horizontalHeader().setStretchLastSection(True)
        self._col_table.setMinimumHeight(140)
        mark_editor_panel(self._col_table)
        columns.card.layout().addWidget(self._col_table, 1)
        columns_layout = columns.layout()
        if isinstance(columns_layout, QBoxLayout):
            columns_layout.setStretch(columns_layout.count() - 1, 1)
        left_layout.addWidget(columns, 1)

        self.settings_layout.addWidget(left, 1)

        # ---------------- Right: preview ----------------
        self._preview = TablePreviewPanel(self.content_frame, self._repo)
        self._preview.refresh.connect(self._schedule_preview)
        self.content_layout.addWidget(self._preview, 1)

        self._btn_ok = self.add_action("apply", self._on_accept, default=True)
        self.add_action("close", self.reject)

        # ---------------- Events & shortcuts ----------------

        if hasattr(self, "_sheet"):
            self._sheet.currentIndexChanged.connect(lambda _=0: self._on_sheet_changed())  # type: ignore

        # Auto preview ONLY when browse is selected
        self._has_header.stateChanged.connect(self._schedule_preview)  # type: ignore
        self._skip_rows.valueChanged.connect(self._schedule_preview)  # type: ignore
        self._skip_last.valueChanged.connect(self._schedule_preview)  # type: ignore
        self._delim.currentIndexChanged.connect(self._schedule_preview)  # type: ignore
        self._delim.editTextChanged.connect(self._schedule_preview)  # type: ignore
        self._encoding.currentIndexChanged.connect(self._schedule_preview)  # type: ignore
        self._encoding.editTextChanged.connect(self._schedule_preview)  # type: ignore

        # Clipboard shortcut
        self._sc_paste = QShortcut(QKeySequence(QKeySequence.StandardKey.Paste), self)
        self._sc_paste.activated.connect(self._on_load_clipboard)  # type: ignore

        self._preview_timer = QTimer(self)
        self._preview_timer.setSingleShot(True)
        self._preview_timer.timeout.connect(self._refresh_preview)  # type: ignore

        self.file_name:str=""

    # ------------------------------------------------------------------
    # Preview
    # ------------------------------------------------------------------
    def _schedule_preview(self) -> None:
        """Re-read the current source after the options settle.

        Pasted text is re-read too. Header, delimiter and the two skip counts
        describe how to *parse* a source, not where it came from, so a paste
        that landed with the wrong delimiter used to be unfixable without
        pasting it again.
        """
        if self._source_mode == "none":
            return
        self._preview_timer.start(250)

    def _current_delim(self) -> str | None:
        data = self._delim.currentData()
        if data is not None:
            return str(data)
        txt = (self._delim.currentText() or "").strip()
        if not txt or txt.lower() == "auto":
            return None
        if txt.lower() in ("tab", "\\t"):
            return "\t"
        if txt.lower() == "space":
            return " "
        return txt

    def _current_encoding(self) -> str | None:
        txt = (self._encoding.currentText() or "").strip()
        if not txt or txt.lower() == "auto":
            return None
        return txt

    def _is_excel_path(self, path: str) -> bool:
        ext = (Path(path).suffix or "").lower()
        return ext in (".xlsx", ".xlsm", ".xls")

    def _current_sheet(self) -> str | None:
        if not hasattr(self, "_sheet"):
            return None
        if not self._sheet.isVisible() or self._sheet.count() == 0:
            return None
        data = self._sheet.currentData()
        return str(data) if data else (str(self._sheet.currentText() or "") or None)

    def _set_sheet_row_visible(self, visible: bool) -> None:
        self._sheet.setVisible(visible)
        self._sheet.setEnabled(visible)
        self._sheet_label.setVisible(visible)

    def _update_sheet_choices(self, path: str) -> None:
        if not hasattr(self, "_sheet"):
            return

        if not self._is_excel_path(path):
            self._sheet.blockSignals(True)
            try:
                self._sheet.clear()
                self._set_sheet_row_visible(False)
            finally:
                self._sheet.blockSignals(False)
            return

        sheets: list[str] = []
        try:
            ext = (Path(path).suffix or "").lower()
            engine = "openpyxl" if ext in (".xlsx", ".xlsm") else None
            xls = pd.ExcelFile(path, engine=engine)
            sheets = [str(s) for s in (xls.sheet_names or [])]
        except Exception as exc:  # noqa: BLE001
            applogger.warning("Cannot read Excel sheet names for %s: %s", path, exc)
            sheets = []

        self._sheet.blockSignals(True)
        try:
            self._sheet.clear()
            if sheets:
                for s in sheets:
                    self._sheet.addItem(s, userData=s)
                if self._desired_sheet:
                    idx = self._sheet.findData(self._desired_sheet)
                    if idx >= 0:
                        self._sheet.setCurrentIndex(idx)
                self._set_sheet_row_visible(True)
            else:
                self._set_sheet_row_visible(False)
        finally:
            self._sheet.blockSignals(False)

    def _on_sheet_changed(self) -> None:
        if self._source_mode == "file":
            self._refresh_preview()

    def _refresh_preview(self) -> None:
        """Re-read whichever source is current and show it.

        Dispatching on the source mode is the point. This used to read
        ``self.file_name`` and nothing else, so a paste that arrived after a
        file had been opened was overwritten by that file the moment anything
        called this - which the paste handler itself did, on its last line.
        """
        if self._source_mode == "clipboard":
            failure = self._show_frame(self._read_clipboard_source)
            if failure is not None:
                show_message(self, "import.clipboard_failed", error=failure)
            return

        if self._source_mode == "web":
            failure = self._show_frame(self._read_web_source)
            if failure is not None:
                show_message(self, "import.web_failed", error=failure)
            return

        path = (self.file_name or "").strip()
        if not path or not Path(path).exists():
            return

        failure = self._show_frame(lambda: self._read_source(path))
        if failure is not None:
            show_message(self, "import.preview_failed", error=failure)

    def _show_frame(self, read: Callable[[], pd.DataFrame]) -> Exception | None:
        """Read one source through *read*, then fill the columns and preview.

        Shared by the file and the clipboard because the only difference
        between them is the reading; everything after it - cleaning, the type
        table, hiding the empty columns from the preview - is the same work,
        and was the same work written twice.

        The failure is returned rather than reported, so that each caller
        names its own catalogue message at its own call site. The ids have to
        be literals where show_message is called: that is what the sweep
        proving every id is defined, and every defined id used, can see.
        """
        try:
            self._df = read()
            self._apply_skip_last_and_clean()

            # Columns: keep empty columns (default Ignore)
            self._build_columns_table(include_empty=True)

            # Preview: hide empty columns
            df_prev = self._df
            if df_prev is not None:
                empty_cols = self._empty_columns(df_prev)
                if empty_cols:
                    df_prev = df_prev.drop(columns=empty_cols)

            if df_prev is None:
                self._preview.clear()
            else:
                self._preview.set_model(DataFramePreviewModel(df_prev, parent=self._preview.view))

            return None

        except Exception as exc:  # noqa: BLE001
            applogger.exception("Preview failed: %s", exc)
            self._df = None
            self._preview.clear()
            self._col_table.setRowCount(0)
            return exc

    def _read_clipboard_source(self) -> pd.DataFrame:
        """Parse the remembered clipboard text with the current options."""
        frame = self._parse_clipboard(self._clipboard_text, self._clipboard_transposed)
        if frame is None:
            # Said here rather than left to fail further on, where an empty
            # clipboard read as a confusing error about a missing table.
            raise ValueError("The clipboard holds no text to import.")
        return frame


    def _read_web_source(self) -> pd.DataFrame:
        """Fetch and parse the remembered URL with the current options."""
        return read_web_url(
            self._path,
            skiprows=int(self._skip_rows.value()),
            skipfooter=int(self._skip_last.value()),
            header=bool(self._has_header.isChecked()),
            sheet=self._current_sheet(),
            delim=self._current_delim(),
            encoding=self._current_encoding(),
        )

    def _read_source(self, path: str) -> pd.DataFrame:
        delim = self._current_delim()
        encoding = self._current_encoding()
        skiprows = int(self._skip_rows.value())
        skipfooter = int(self._skip_last.value())
        header = bool(self._has_header.isChecked())

        return read_any_file(
            path,
            skiprows=skiprows,
            skipfooter=skipfooter,
            header=header,
            sheet=self._current_sheet(),
            delim=delim,
            encoding=encoding,
        )

    def _apply_skip_last_and_clean(self) -> None:
        if self._df is None:
            return
        self._df.columns = [str(c).strip() for c in self._df.columns]
        skip_last = int(self._skip_last.value())
        if skip_last > 0 and len(self._df) > 0:
            self._df = self._df.iloc[: max(0, len(self._df) - skip_last)]

    @staticmethod
    def _empty_columns(df: pd.DataFrame) -> list[str]:
        empties: list[str] = []
        for col in df.columns:
            s = df[col]
            if s.isna().all():
                empties.append(str(col))
                continue
            try:
                ss = s.astype(str).str.strip().replace("nan", "")
                if ss.eq("").all():
                    empties.append(str(col))
            except Exception:
                pass
        return empties

    # ------------------------------------------------------------------
    # Column typing
    # ------------------------------------------------------------------
    def _build_columns_table(self, *, include_empty: bool) -> None:
        df = self._df
        self._col_table.setRowCount(0)
        if df is None or df.empty:
            return

        empty_cols = set(self._empty_columns(df))
        cols = [str(c) for c in df.columns]
        if not include_empty:
            cols = [c for c in cols if c not in empty_cols]

        self._col_table.setRowCount(len(cols))
        for r, col in enumerate(cols):
            it_name = QTableWidgetItem(col)
            it_name.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            self._col_table.setItem(r, 0, it_name)

            combo = QComboBox(self._col_table)
            combo.addItems(self.SQLITE_TYPES)
            if col in empty_cols:
                combo.setCurrentText("Ignore")
            else:
                combo.setCurrentText(self._guess_sqlite_type(df[col]))
            self._col_table.setCellWidget(r, 1, combo)

        self._col_table.resizeColumnsToContents()


    @staticmethod
    def _guess_sqlite_type(series: pd.Series) -> str:
        try:
            s = series.dropna()
            if s.empty:
                return "Ignore"
            if pd.api.types.is_integer_dtype(s):
                return "INTEGER"
            if pd.api.types.is_float_dtype(s):
                return "REAL"
            if pd.api.types.is_bool_dtype(s):
                return "INTEGER"
            if pd.api.types.is_datetime64_any_dtype(s):
                return "DATETIME"
        except Exception:
            pass
        return "TEXT"

    def _selected_types(self) -> dict[str, str]:
        mapping: dict[str, str] = {}
        for r in range(self._col_table.rowCount()):
            name_it = self._col_table.item(r, 0)
            if not name_it:
                continue
            col = name_it.text()
            combo = self._col_table.cellWidget(r, 1)
            if not isinstance(combo, QComboBox):
                continue
            t = combo.currentText().strip().upper()
            if t == "IGNORE":
                continue
            mapping[col] = t
        return mapping

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def _set_file_name_label(self, path: str) -> None:
        p = Path((path or "").strip())
        if not path or not p.name:
            self.file_name=""
            self.setWindowTitle(_("Import data"))
            return
        self.file_name=path
        self.setWindowTitle(f"Import data: {path}")


    def _safe_table_name_from_filename(self,path: str) -> str:
        base = path if path == CLIPBOARD_SOURCE_NAME else Path(path).stem.strip()
        if not base:
            base = "new_table"
        name = re.sub(r"[^0-9a-zA-Z_]+", "_", base)
        if not re.match(r"^[A-Za-z_]", name):
            name = "t_" + name
        name = name.strip("_") or "new_table"
        nname=name
        iter:int=1
        while self._repo.check_if_table_exists(nname):
            nname=name+"_"+str(iter)
            iter+=1    
        return nname

    def _set_default_table_name(self, path: str) -> None:
        auto = self._safe_table_name_from_filename(path)
        self._table.setText(auto)
        self._last_auto_table = auto

    def _on_browse(self) -> None:
        path, _unused = QFileDialog.getOpenFileName(
            self,
            _("Select file"),
            str(Path.home()),
            IMPORT_FILE_FILTER,
        )
        if not path:
            return
        self.load_file(path)

    def load_file(self, path: str | Path) -> None:
        name = str(path)
        self._source_mode = "file"
        self._set_file_name_label(name)
        self._set_default_table_name(name)
        self._path = name
        self._update_sheet_choices(name)
        self._refresh_preview()

    def _parse_clipboard(self, text: str, transposed: bool) -> pd.DataFrame | None:
        """Read *text* with the current options, rows and columns swapped first if asked.

        Transposed, the skip counts and the header refer to the table as it
        is shown - after the swap - and the delimiter to the text as copied.
        """
        if transposed:
            text = transpose_delimited_text(text, self._current_delim())
        return read_clipboard_text(
            text,
            skiprows=int(self._skip_rows.value()),
            skipfooter=int(self._skip_last.value()),
            header=bool(self._has_header.isChecked()),
            delimiter="\t" if transposed else self._current_delim(),
        )

    def _on_load_clipboard(self, transposed: bool = False) -> None:
        """Replace whatever is loaded with what is on the clipboard.

        *Replace* is the whole job. The clipboard becomes the source, so the
        file - if one was opened - stops being it: the remembered path, the
        window title and the sheet list all go, and the table name is taken
        from the clipboard rather than left naming a file the preview no
        longer shows.

        The text is kept rather than only its parse. Header, delimiter and
        the skip counts can be changed afterwards, and re-reading the source
        is how they take effect - which needs the source still to be here.
        """
        text = QApplication.clipboard().text() or ""

        # Parsed before anything is replaced: an empty clipboard must leave
        # the dialog exactly as it was, not clear it and then say why.
        try:
            probe = self._parse_clipboard(text, transposed)
        except Exception as exc:  # noqa: BLE001
            applogger.exception("Clipboard preview failed: %s", exc)
            show_message(self, "import.clipboard_failed", error=exc)
            return

        if probe is None or probe.empty:
            show_message(self, "import.clipboard_empty")
            return

        self._source_mode = "clipboard"
        self._clipboard_text = text
        self._clipboard_transposed = transposed
        self._path = ""
        self._set_file_name_label("")
        self._update_sheet_choices("")
        self._set_default_table_name(CLIPBOARD_SOURCE_NAME)

        self._refresh_preview()

    def _on_web_source_picked(self, source: WebDataSource) -> None:
        """Fill the URL field from the chosen quick-pick source.

        Fills the field rather than fetching immediately: a URL from the
        catalogue is still a URL, and the person picking it should see it -
        and be free to edit it, e.g. PubChem's CID - before anything is
        downloaded.
        """
        self._picked_web_source = source
        self._url.setText(source.url)
        self._url.setToolTip(source.description)
        # Only a source the user added themselves can be removed again - a
        # bundled entry ships with the application, not with this project.
        self._btn_delete_web_source.setEnabled(source.custom)

    def _rebuild_web_source_menu(self) -> None:
        """(Re)build the quick-pick menu from the current catalogue.

        Called once at construction and again after Add/Delete Source, since
        either changes what ``load_web_data_sources()`` returns.
        """
        # Every entry gets the same icon rather than one per category: what
        # they have in common is that picking one downloads something, which
        # is exactly what the "fetch_url" action already draws - reusing it
        # needs no new catalogue entry, and a dozen bespoke subject glyphs
        # (Astronomy, Sports, Entertainment...) would each need an SF Symbol,
        # a Segoe Fluent glyph and a freedesktop theme name of their own to
        # match how every other icon in this application is sourced.
        entry_icon = load_icon("fetch_url")
        self._web_source_menu.clear()
        by_category: dict[str, list[WebDataSource]] = {}
        for source in load_web_data_sources():
            by_category.setdefault(source.category, []).append(source)
        for category, sources in by_category.items():
            # Categories and dataset names are data, not source text - see
            # the note above on _(): they are deliberately not translated.
            # USER_WEB_SOURCE_CATEGORY is no exception: it reads the same as
            # every other category here, plain text rather than chrome.
            self._web_source_menu.addSection(category)
            for source in sources:
                menu_action = self._web_source_menu.addAction(entry_icon, source.name)
                menu_action.setToolTip(source.description)
                menu_action.triggered.connect(
                    lambda _checked=False, s=source: self._on_web_source_picked(s)
                )

    def _on_add_web_source(self) -> None:
        """Add a source of the user's own to the quick-pick catalogue."""
        dialog = _AddWebSourceDialog(self)
        if not dialog.exec():
            return
        source = add_user_web_source(dialog.name, dialog.url, dialog.description)
        self._rebuild_web_source_menu()
        self._on_web_source_picked(source)

    def _on_delete_web_source(self) -> None:
        """Remove the selected source from the user's own catalogue.

        The button is only enabled while the last-picked source is one the
        user added themselves (see ``_on_web_source_picked``), so this never
        runs against a bundled entry.
        """
        picked = self._picked_web_source
        if picked is None or not picked.custom:
            return
        remove_user_web_source(picked.name)
        self._picked_web_source = None
        self._btn_delete_web_source.setEnabled(False)
        self._rebuild_web_source_menu()

    def _on_fetch_url(self) -> None:
        """Download the URL in the web-source field and load it as this
        dialog's web source.

        Fetched once as a probe before anything replaces the current source,
        the same way the clipboard is - a typo in the URL or an unreachable
        host must leave the dialog exactly as it was, not clear it first and
        say why afterwards.
        """
        url = (self._url.text() or "").strip()
        if not url:
            return

        if not is_valid_web_url(url):
            show_message(self, "import.web_invalid_url")
            return

        try:
            probe = read_web_url(
                url,
                skiprows=int(self._skip_rows.value()),
                skipfooter=int(self._skip_last.value()),
                header=bool(self._has_header.isChecked()),
                sheet=None,
                delim=self._current_delim(),
                encoding=self._current_encoding(),
            )
        except Exception as exc:  # noqa: BLE001
            applogger.exception("Web import failed: %s", exc)
            show_message(self, "import.web_failed", error=exc)
            return

        if probe is None or probe.empty:
            show_message(self, "import.nothing_to_import")
            return

        self._source_mode = "web"
        self._path = url
        self._set_file_name_label(url)
        self._update_sheet_choices("")

        # A quick-pick source names the table for what it is; a typed-in URL
        # falls back to its own file name.
        picked = self._picked_web_source
        table_name_seed = picked.name if picked is not None and picked.url == url else filename_from_url(url)
        self._set_default_table_name(table_name_seed)

        self._refresh_preview()

    def _on_accept(self) -> None:
        if self._df is None:
            # If user did not press Preview, read once for import.
            self._refresh_preview()

        df = self._df
        if df is None or df.empty:
            applogger.info("Import aborted: no data to import")
            show_message(self, "import.nothing_to_import")
            return

        table = (self._table.text() or "").strip()
        if not table:
            show_message(self, "import.no_table_name")
            return

        types = {k: v for k, v in self._selected_types().items() if v.lower() != "ignore"}
        cols_keep = [c for c in df.columns if c in types]
        if not cols_keep:
            applogger.info("Import aborted: no columns to import")
            show_message(self, "import.no_columns_selected")
            return

        df2 = df[cols_keep].copy()
        df2 = self._coerce_df(df2, types)
        set_import_data_dialog_config(
            {
                "table": table,
                "header": bool(self._has_header.isChecked()),
                "skip_rows": int(self._skip_rows.value()),
                "skip_last": int(self._skip_last.value()),
                "delim": self._current_delim() or "",
                "encoding": self._current_encoding() or "auto",
                "sheet": self._current_sheet() or "",
            }
        )
        try:
            table_name=self._safe_table_name_from_filename(table)
            self._repo.import_into_sqlite(table_name, df2, types)

            source = self._link_source_settings()
            if source is not None:
                link_settings = {
                    "source": source,
                    "read": {
                        "skiprows": int(self._skip_rows.value()),
                        "skip_last": int(self._skip_last.value()),
                        "header": bool(self._has_header.isChecked()),
                        "delimiter": self._current_delim(),
                        "encoding": self._current_encoding(),
                    },
                    "destination": {"table": table_name, "normalize_columns": True},
                    "columns": {"types": types},
                }
                if not self._repo.upsert_link(
                    table_name=table_name,
                    source_path=self._path,
                    settings=link_settings,
                ):
                    applogger.warning("Failed to create link for imported table '%s'", table_name)
        except Exception as exc:  # noqa: BLE001
            applogger.exception("Import failed: %s", exc)
            show_message(self, "import.failed", error=exc)
            return

        self.import_result = ImportResult(table_name=table, rows=int(len(df2)), cols=int(len(df2.columns)))
        self.accept()

    def _link_source_settings(self) -> dict[str, object] | None:
        """Return the ``source`` dict a saved link should remember, or None.

        Every source that can meaningfully be read again gets one - file,
         a URL. Pasted text cannot: there is nothing left
        to reread once the clipboard has moved on, so "Update link" has
        nothing to offer it and none is created.
        """
        if self._source_mode == "file":
            return {"kind": "file", "path": self._path, "sheet": self._current_sheet()}
        if self._source_mode == "web":
            return {"kind": "web", "url": self._path}
        return None

    @staticmethod
    def _coerce_df(df: pd.DataFrame, types: dict[str, str]) -> pd.DataFrame:
        out = df.copy()
        for col, t in types.items():
            if col not in out.columns:
                continue
            tt = t.upper()
            s = out[col]

            if tt == "INTEGER":
                out[col] = to_numbers(s).astype("Int64")
            elif tt == "REAL":
                out[col] = to_numbers(s)
            elif tt in ("DATE", "TIME", "DATETIME"):
                dt = pd.to_datetime(s, errors="coerce")
                if tt == "DATE":
                    out[col] = dt.dt.date.astype("string")
                elif tt == "TIME":
                    out[col] = dt.dt.time.astype("string")
                else:
                    out[col] = dt.dt.strftime("%Y-%m-%d %H:%M:%S").astype("string")
            elif tt == "BLOB":
                out[col] = s.apply(
                    lambda v: v
                    if isinstance(v, (bytes, bytearray))
                    else ("" if pd.isna(v) else str(v)).encode("utf-8")
                )
            else:
                out[col] = s.astype("string")

        return out