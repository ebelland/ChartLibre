"""The hooks a series operation fills in: its model selector, parameters, fields and sampling rate."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, ClassVar

from PySide6.QtWidgets import (
    QCheckBox,
    QDoubleSpinBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QSpinBox,
    QWidget,
)
import numpy as np

from app.analysis.sampling import sampling_frequency
from app.data.sqlite_repo import DatabaseError
from app.styles.style import create_doc_link, CardFrame, stdSizeAndlayout
from app.logs.logger import applogger
from app.series_operations.parameter_form import ParameterForm
from app.series_operations.parameter_spec import Param, defaults
from app.utils.i18n import _

from app.series_operations.dialog_base.common import OperationModel


class BuilderHooksMixin:
    """The hooks a series operation fills in: its model selector, parameters, fields and sampling rate. A part of SeriesOperationDialogBase (see dialog.py)."""

    # ------------------------------------------------------------------
    # Builder hooks
    # ------------------------------------------------------------------
    def init_operation_widgets(self) -> None:
        """Create subclass widgets before build_model_selector/build_parameter_selector.

        The base constructor calls the builder hooks, so subclasses must create
        controls used by those hooks here rather than after super().__init__().
        """
        return None

    #: The models this operation offers, in the order the Model combo lists
    #: them: name -> OperationModel. Setting it gives the operation the
    #: standard selector - "Model:" with the combo, "Docs:" with a link kept
    #: on the selected model - without writing build_model_selector.
    MODELS: ClassVar[Mapping[str, OperationModel]] = {}
    #: The combo's tooltip, when MODELS builds it.
    MODEL_TOOLTIP: ClassVar[str] = "Choose the model."
    #: The combo's label, when MODELS builds it ("Operation:", "Method:"...).
    MODEL_LABEL: ClassVar[str] = "Model:"

    def build_model_selector(self) -> QWidget:
        """The Model combo and its Docs link, from MODELS.

        Without MODELS, just the shared model_combo, for an operation that
        fills it itself.
        """
        if not self.MODELS:
            panel = CardFrame(self, "operationModelCard")
            layout = panel.layout()
            stdSizeAndlayout(self.model_combo)
            layout.addWidget(self.model_combo)
            return panel

        if getattr(self, "_doc_link", None) is None:
            self._doc_link = create_doc_link(self)
        panel = QWidget(self)
        form = QFormLayout(panel)
        form.setContentsMargins(0, 0, 0, 0)
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        # Connected before the items go in: the first addItems selects item 0
        # and emits, which is what puts the first model's link in place.
        self.model_combo.currentIndexChanged.connect(self._update_doc_link)
        self.model_combo.addItems(list(self.MODELS))
        # A line between groups, inserted from the end so earlier indices hold.
        groups = [model.group for model in self.MODELS.values()]
        for index in range(len(groups) - 1, 0, -1):
            if groups[index] != groups[index - 1]:
                self.model_combo.insertSeparator(index)
        self.model_combo.setToolTip(_(self.MODEL_TOOLTIP))
        form.addRow(_(self.MODEL_LABEL), self.model_combo)
        form.addRow(_("Docs:"), self._doc_link)
        return panel

    def model_spec(self) -> OperationModel | None:
        """The OperationModel of the selected model, when MODELS has it."""
        return self.MODELS.get(self.current_model())

    def _update_doc_link(self, *_ignored: Any) -> None:
        spec = self.model_spec()
        if spec is not None:
            self.set_doc_link(*spec.doc)

    
    #: Whether the figure combo is disabled. True for every operation so far;
    #: an operation that genuinely means to move between figures would have to
    #: keep self._figure_id in step with it, which none currently does.
    LOCK_FIGURE_SELECTION: bool = True

    #: Whether the series list is shown. An operation that generates a series
    #: rather than transforming one has nothing to select, and a picker it
    #: never reads is worse than no picker.
    SHOWS_SERIES_SELECTOR: bool = True

    #: Whether the Axis / Series page appears in the toolbox at all. The
    #: selector itself is still built and still answers selected_axis_id(),
    #: because _run_operation needs an axis to write to - this only decides
    #: whether the user is shown a page they have no decision to make on.
    SHOWS_AXIS_SERIES_PAGE: bool = True

    #: Whether the data can come from a table's columns instead of a chart's
    #: series: "Data from: Chart | Table" on the Axis / Series page. The
    #: columns are drawn as a figure of their own first (see
    #: _prepare_table_source), so the operation runs on series as always.
    READS_TABLES: bool = True

    #: Declared parameters.  An operation that sets this gets its parameter
    #: form built, wired and read back for free; see ``parameter_spec``.
    #: Leaving it empty keeps the old behaviour, where the subclass overrides
    #: ``build_parameter_selector`` and builds the form by hand - which is
    #: still the right answer for a genuinely unusual control.
    PARAMS: tuple[Param, ...] = ()

    def extra_tabs(self) -> list[tuple[QWidget, str]]:
        """Further (page, title) tabs after Parameters, for an operation with more to set."""
        return []

    def build_parameter_selector(self) -> QWidget:
        """Return the parameter editor widget for the left panel.

        Builds itself from ``PARAMS`` when the operation declares any.  An
        operation that declares none must override this - hence the empty
        widget rather than NotImplementedError, which is what the dialogs
        written before ``PARAMS`` existed rely on.
        """
        if not self.PARAMS:
            return QWidget(self)

        self._parameter_form_spec = ParameterForm(
            self.PARAMS,
            self,
            on_change=self.mark_results_stale,
            context=self.parameter_context,
        )
        # Kept under the name the base already uses for the hand-built form, so
        # set_row_visible and the state helpers keep working unchanged.
        self._parameter_form = self._parameter_form_spec.layout
        return self._parameter_form_spec.widget

    def parameter_context(self) -> Mapping[str, Any]:
        """Return values a ``visible_for`` rule may reference but not own.

        The model combo by default, under the name ``model``: nearly every
        operation's parameter visibility depends on which model is selected,
        and the combo belongs to this base rather than to ``PARAMS``.
        """
        combo = getattr(self, "model_combo", None)
        if combo is None:
            return {}
        return {"model": self.current_model()}

    def parameter_values(self) -> dict[str, Any]:
        """Return the declared parameters' current values, keyed by name.

        Falls back to the declared defaults when there is no form yet, so an
        operation can call this from ``compute_results`` during construction
        without a special case.
        """
        form = getattr(self, "_parameter_form_spec", None)
        if form is None:
            return defaults(self.PARAMS)
        return form.values()

    def build_results_pane(self) -> QWidget:
        """Return the shared HTML results widget."""
        return self._results_view

    def build_extra_action_buttons(self, layout: QHBoxLayout) -> None:
        """Add operation-specific buttons to the bottom row, after Preview.

        Only one operation needs this so far - fitting, where optimising the
        parameters is a separate act from drawing them - but putting the button
        in the shared row is what keeps it in the same place as every other
        dialog's buttons.
        """
        del layout

    def connect_common_signals(self) -> None:
        """Wire signals common to selector-based operation dialogs."""
        selection_changed = getattr(self.series_selector, "selection_changed", None)
        if selection_changed is not None:
            selection_changed.connect(lambda *_args: self.mark_results_stale())
            selection_changed.connect(lambda *_args: self._update_origin_label())
        self._update_origin_label()
    
    def connect_operation_signals(self) -> None:
        """Connect the model selector; subclasses add their own widgets.

        A different model shows different parameters and makes the results
        on screen stale - true of every operation, so wired here once. An
        override that connects more calls super() first.
        """
        self.model_combo.currentIndexChanged.connect(self._refresh_visibility)
        self.model_combo.currentIndexChanged.connect(self.mark_results_stale)

    def _refresh_visibility(self, *_ignored: Any) -> None:
        """Show the parameters the selected model uses: the PARAMS' visible_for rules.

        Eight operations had this same body as their own; one that builds
        its controls by hand overrides it (or calls this, then adds its own).
        """
        form = getattr(self, "_parameter_form_spec", None)
        if form is not None:
            form.refresh_visibility()

    # -- For operations that build their own controls ----------------------

    def model_form_card(self, object_name: str, rows: Sequence[tuple[str, QWidget]]) -> CardFrame:
        """A card with the model choices as a form, and the Docs link last.

        For an operation with more than the one model combo build_model_selector
        lays out (Cluster's family and algorithm, Smoothing's data type and
        method).
        """
        panel = CardFrame(self, object_name)
        form_widget = QWidget(panel)
        form = QFormLayout(form_widget)
        stdSizeAndlayout(form)
        for label, widget in rows:
            form.addRow(label, widget)
        if getattr(self, "_doc_link", None) is None:
            self._doc_link = create_doc_link(self)
        form.addRow(_("Docs:"), self._doc_link)
        panel.layout().addWidget(form_widget)
        return panel

    def add_field_row(
        self, form: QFormLayout, key: str, label: str, widget: QWidget, tooltip: str = ""
    ) -> None:
        """Add one parameter row that show_field_rows can show or hide by *key*."""
        row_widget = QWidget()
        row_layout = QHBoxLayout(row_widget)
        stdSizeAndlayout(row_layout)
        row_layout.addWidget(widget)
        row_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        label_widget = QLabel(label)
        if tooltip:
            widget.setToolTip(tooltip)
            label_widget.setToolTip(tooltip)
        form.addRow(label_widget, row_widget)
        rows: dict[str, tuple[QWidget, QWidget]] = self.__dict__.setdefault("_field_rows", {})
        rows[key] = (label_widget, row_widget)

    def show_field_rows(self, visible: set[str] | frozenset[str]) -> None:
        """Show the rows add_field_row made whose key is in *visible*, hide the rest."""
        for key, (label_widget, row_widget) in getattr(self, "_field_rows", {}).items():
            label_widget.setVisible(key in visible)
            row_widget.setVisible(key in visible)

    # -- A result on an axis or figure of its own -------------------------

    def result_figure_name(self, results: Sequence[Any], what: str = "", source: str = "") -> str:
        """"<source> - <what was done>": what names a figure an operation makes.

        "Calculus 1" in a tab bar says nothing a week later; the series and
        the operation do. *source* defaults to the first result's source_name.
        """
        if not source and results:
            source = str(getattr(results[0], "source_name", "") or "")
        return f"{source} - {what or self.operation_label}".strip(" -") or self.operation_label

    def label_result_axis(self, *, title: str, x_label: str = "x", y_label: str = "y") -> None:
        """Title and label the axis this operation made for its results, if it made one."""
        axis_id = getattr(self, "_result_axis_id", None)
        if axis_id is None:
            return
        try:
            self._repo.update_axis_descriptor(axis_id=axis_id, title=title, x_label=x_label, y_label=y_label)
        except (DatabaseError, ValueError):
            applogger.exception(f"Failed to label the {self.operation_label} result axis")

    def current_model(self, default: str | None = None) -> str:
        """The selected model's key, or *default* while none is selected.

        The item's data when it has any - a combo that shows translated names
        keeps the untranslated one there, and that is what visible_for rules
        and the code compare against - otherwise its text. With no *default*,
        the first of MODELS: the one the combo starts on.
        """
        data = self.model_combo.currentData()
        if data is not None and str(data):
            return str(data)
        if default is None:
            default = next(iter(self.MODELS), "")
        return self.model_combo.currentText() or default

    def current_axis_name(self) -> str:
        """The name of the axis picked in the Data page."""
        return self.series_selector.selected_axis_name()

    # -- Small controls, for operations that build their own forms ---------

    @staticmethod
    def int_spin(minimum: int, maximum: int, value: int) -> QSpinBox:
        """A spin box over [minimum, maximum], set to *value*."""
        widget = QSpinBox()
        widget.setRange(minimum, maximum)
        widget.setValue(value)
        return widget

    @staticmethod
    def float_spin(minimum: float, maximum: float, value: float, decimals: int) -> QDoubleSpinBox:
        """A decimal spin box, stepping by its last shown decimal (0.001 at most)."""
        widget = QDoubleSpinBox()
        widget.setRange(minimum, maximum)
        widget.setValue(value)
        widget.setDecimals(decimals)
        widget.setSingleStep(10 ** -min(decimals, 3))
        return widget

    # -- Sampling rate: the "derive it from x, or type it" pair -----------

    def create_sampling_rate_widgets(self, check_text: str = "") -> None:
        """Create ``_fs_auto_check`` and ``_fs_spin``; call from init_operation_widgets."""
        self._fs_auto_check = QCheckBox(check_text, self)
        self._fs_spin = QDoubleSpinBox(self)

    def add_sampling_rate_rows(self, form: QFormLayout) -> None:
        """Set up the sampling-rate pair and add it to *form* as two rows."""
        self._fs_auto_check.setChecked(True)
        self._fs_auto_check.setToolTip(
            _("Take the sampling frequency from the spacing of the x role.")
        )
        form.addRow(_("Sampling rate:"), self._fs_auto_check)
        self._fs_spin.setRange(1e-9, 1e12)
        self._fs_spin.setDecimals(6)
        self._fs_spin.setValue(1.0)
        self._fs_spin.setToolTip(_("Samples per unit of x, used when not derived."))
        form.addRow(_("fs:"), self._fs_spin)

    def sampling_rate(self, x_values: np.ndarray, name: str) -> float:
        """fs in samples per unit of x: the typed one, or read off the x role."""
        if not self._fs_auto_check.isChecked():
            return float(self._fs_spin.value())
        fs, note = sampling_frequency(x_values)
        if note:
            applogger.warning(
                "Series '%s': %s.", name, note,
            )
        return fs
