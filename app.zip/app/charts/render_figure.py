"""Render a figure descriptor tree onto a Matplotlib figure.

Responsibilities and non-responsibilities are deliberately split: this module
creates axes, loads series data, dispatches to renderers, and applies layout.
It does **not** own figure width, height, or DPI - those belong to ChartPanel
and to rcParams, so the same descriptor renders identically on screen and on
export.

Series data is read through ``SqliteRepo.series_frame`` so that repeated
renders of an unchanged database are served from cache - and, since todo.txt
P2-17, without a ``pd.DataFrame`` built on the way: see
``app.data.series_frame`` for what a series looks like now.
"""
from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import replace
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any, Literal

import math

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.figure import Figure
from matplotlib.ticker import NullLocator

from app.scanners.axis_renderer_scanner import get_renderer, import_class_from_file
from app.charts import axis_options
from app.charts.base import SeriesData
from app.data.descriptors import AxisDescriptor, FigureDescriptor, SeriesDescriptor
from app.data.series_frame import SeriesFrame
from app.data.sqlite_repo import SqliteRepo
from app.logs.logger import applogger
from app.utils.config import MPLSTYLES_DIR, get_constant, get_value
from app.utils.mpl_latex import filter_latex_style_text
from app.utils.coercion import to_numbers


LayoutMode = Literal["constrained", "compressed", "tight", "none"]


# ----------------------------------------------------------------------
# Context helpers
# ----------------------------------------------------------------------
#: Settings key: the .mplstyle (name, no extension) a figure without its own style uses.
DEFAULT_MPL_STYLE_KEY = "default_mpl_style"


@contextmanager
def _figure_style_context(
    fig_desc: FigureDescriptor,
) -> Generator[None, None, None]:
    """Apply raw mplstyle text from figure options, if present.

    LaTeX-dependent entries are stripped when no TeX installation is available,
    otherwise every text draw in the figure would raise.
    """
    options = fig_desc.options if isinstance(fig_desc.options, dict) else {}
    style_text = options.get("mpl_style")
    if not isinstance(style_text, str) or not style_text.strip():
        # A figure with no style of its own takes the one chosen in Settings.
        style_text = default_style_text()

    if not isinstance(style_text, str) or not style_text.strip():
        yield
        return

    style_text = filter_latex_style_text(style_text)

    temp_path: Path | None = None
    try:
        with NamedTemporaryFile(
            mode="w",
            suffix=".mplstyle",
            delete=False,
            encoding="utf-8",
        ) as handle:
            handle.write(style_text)
            temp_path = Path(handle.name)

        with plt.style.context(str(temp_path)):  # pyright: ignore[reportGeneralTypeIssues]
            yield
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def default_style_text() -> str:
    """The .mplstyle chosen in Settings as every new figure's default; empty for Matplotlib's.

    The setting is the style's path under mplstyles without its extension:
    "ChartLibreDefault", or "Apps/jmp-classic" for one in a subfolder.
    """
    name = str(get_value(DEFAULT_MPL_STYLE_KEY) or "").strip()
    if not name:
        return ""
    path = MPLSTYLES_DIR / f"{name}.mplstyle"
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        applogger.warning("Default style %s not found in %s", name, MPLSTYLES_DIR)
        return ""


# ----------------------------------------------------------------------
# Public renderer entry point
# ----------------------------------------------------------------------
def render_figure_from_descriptor(
    *,
    figure: Figure,
    descriptor: FigureDescriptor,
    repo: SqliteRepo,
) -> None:
    """Render a full figure from a project descriptor.

    The renderer deliberately does not own figure width, height, or DPI.  Those
    values are owned by ChartPanel and rcParams.  This function only creates
    axes, renders series, applies runtime options, and applies final layout.
    """
    figure.clear()
    _set_layout_engine_safely(figure, "none")

    with _figure_style_context(descriptor):
        _apply_figure_options(figure, descriptor)
        downsample_threshold = _figure_downsample_threshold(descriptor)

        all_axes = list(descriptor.axes or [])
        twin_targets = _twin_targets(all_axes)
        base_axes = [a for a in all_axes if int(a.id) not in twin_targets]
        twin_axes = [a for a in all_axes if int(a.id) in twin_targets]

        axes_with_positions, rows, cols, spans_valid = _normalized_axes_for_grid(
            replace(descriptor, axes=base_axes)
        )
        axes_flat, shared_axes = _create_axes_grid(
            figure=figure,
            descriptor=descriptor,
            axes_with_positions=axes_with_positions,
            rows=rows,
            cols=cols,
            respect_spans=spans_valid,
        )

        ax_by_id: dict[int, Any] = {}
        for axis_desc, axis_index in axes_with_positions:
            ax = axes_flat[axis_index]
            if ax is None:
                applogger.error(
                    "No subplot was created for axis id=%r at render position=%r.",
                    axis_desc.id,
                    axis_index,
                )
                return
            ax_by_id[int(axis_desc.id)] = ax

        # Overlapping ("twin") axes share their target's x-axis and grid
        # cell, with their own independent y-scale on the right - the same
        # pairing ``ax.twinx()`` builds by hand, but reached through an axis
        # option instead of a second call site every dual-scale chart would
        # otherwise need. Created after every base axis exists, since a twin
        # is built from its target rather than placed on the grid itself -
        # which is also why it never enters ``_normalized_axes_for_grid``:
        # twin and target sharing a cell is the point, not a layout conflict.
        for axis_desc in twin_axes:
            target_ax = ax_by_id.get(twin_targets[int(axis_desc.id)])
            if target_ax is None:
                applogger.error(
                    "Twin axis id=%r names a target that was not rendered.",
                    axis_desc.id,
                )
                continue
            ax_by_id[int(axis_desc.id)] = target_ax.twinx()

        for axis_desc in all_axes:
            ax = ax_by_id.get(int(axis_desc.id))
            if ax is None:
                # Already reported above, for a base axis; a twin whose
                # target failed to render was already reported too.
                continue
            # Tagged so _normalize_axes_fill_policy can match figure.axes
            # back to their descriptor by id - it cannot rely on the two
            # lists sharing an order once axes are created out of order
            # for one (base axes, then their twins).
            ax._dhub_axis_id = int(axis_desc.id)  # noqa: SLF001 - our own attribute, not matplotlib's

            chart_type = str(axis_desc.name or "").strip()
            series_list = _build_series_data_list(
                repo=repo,
                axis_desc=axis_desc,
                downsample_threshold=(
                    0
                    if chart_type in _GRID_REQUIRED_CHART_TYPES
                    else max(downsample_threshold, POINT_DOWNSAMPLE_THRESHOLD)
                    if chart_type in _POINT_CHART_TYPES and downsample_threshold > 0
                    else downsample_threshold
                ),
            )
            renderer = get_renderer(chart_type)
            if renderer is None:
                applogger.error("Renderer not found for chart_type=%r.", chart_type)
                return

            # A band (a fit's confidence or prediction band) is a filled
            # region between two columns, whatever the axis draws: the chart
            # type belongs to the axis, and a band has to sit on the same axis
            # as the curve and the points it describes. Drawn first, so the
            # data stays on top of it.
            bands = [sd for sd in series_list if sd.style.get("draw_as") == "band"]
            if bands:
                series_list = [sd for sd in series_list if sd.style.get("draw_as") != "band"]
                for band in bands:
                    _draw_band(ax, band)

            try:
                renderer_instance = import_class_from_file(renderer)()  # type: ignore
                renderer_instance.render_axis(
                    ax=ax,
                    series=series_list,
                    options=axis_desc.options if isinstance(axis_desc.options, dict) else {},
                )
            except Exception:
                applogger.exception(
                    "Renderer failed for axis id=%r chart_type=%r.",
                    axis_desc.id,
                    chart_type,
                )
                return

            _apply_axis_runtime_options(ax=ax, axis_desc=axis_desc)

        _apply_shared_z_ranges(all_axes, ax_by_id)
        _clear_redundant_shared_axis_labels(shared_axes)
        _apply_font_scale(figure, descriptor, all_axes, ax_by_id)
        _apply_layout(figure, descriptor)
        _normalize_axes_fill_policy(figure, descriptor)


def _twin_targets(axes: list[AxisDescriptor]) -> dict[int, int]:
    """Return {twin axis id: target axis id} for every valid ``twin_of``.

    An axis option rather than a descriptor column - see ``_axis_span`` for
    the same reasoning. A target has to be another axis in the same figure,
    which rules out a stale id left over from a deleted axis; it also has to
    not itself be a twin, which rules out a chain (twin-of-a-twin) that
    ``ax.twinx()`` cannot express - such an axis is drawn as an ordinary grid
    axis instead of being silently dropped.
    """
    axis_ids = {int(axis_desc.id) for axis_desc in axes}
    targets: dict[int, int] = {}
    for axis_desc in axes:
        options = axis_desc.options if isinstance(axis_desc.options, dict) else {}
        raw_target = options.get("twin_of")
        if raw_target is None or isinstance(raw_target, bool):
            continue
        try:
            target_id = int(raw_target)
        except (TypeError, ValueError):
            continue
        axis_id = int(axis_desc.id)
        if target_id == axis_id or target_id not in axis_ids:
            continue
        targets[axis_id] = target_id

    return {
        axis_id: target_id
        for axis_id, target_id in targets.items()
        if target_id not in targets
    }


# ----------------------------------------------------------------------
# Axes creation / normalization
# ----------------------------------------------------------------------
def _compact_grid_for_axis_count(axis_count: int) -> tuple[int, int]:
    """Return a compact grid that can contain axis_count axes."""
    axis_count = max(1, int(axis_count))
    if axis_count == 1:
        return 1, 1

    ncols = int(math.ceil(math.sqrt(axis_count)))
    nrows = int(math.ceil(axis_count / ncols))
    return max(1, nrows), max(1, ncols)


def _axis_span(axis_desc: AxisDescriptor) -> tuple[int, int]:
    """Return (row_span, col_span) for one axis, at least 1x1.

    Spans let an axis occupy more than one grid cell - the mechanism behind
    every non-uniform layout the Figure options panel offers (one wide plot
    over two narrow ones, an L-shape, and so on). They live in
    ``axis_desc.options`` rather than as descriptor columns because they are
    just another rendering option, no different from a scale or a spine.
    """
    options = axis_desc.options if isinstance(axis_desc.options, dict) else {}
    row_span = options.get("row_span", 1)
    col_span = options.get("col_span", 1)
    try:
        row_span = max(1, int(row_span))
    except (TypeError, ValueError):
        row_span = 1
    try:
        col_span = max(1, int(col_span))
    except (TypeError, ValueError):
        col_span = 1
    return row_span, col_span


def _axis_footprint(
    *, axis_index: int, row_span: int, col_span: int, rows: int, cols: int
) -> set[tuple[int, int]] | None:
    """Return the set of (row, col) cells one axis occupies, or None if it
    does not fit inside the grid starting from its top-left cell."""
    if cols <= 0:
        return None
    row = axis_index // cols
    col = axis_index % cols
    if row + row_span > rows or col + col_span > cols:
        return None
    return {(r, c) for r in range(row, row + row_span) for c in range(col, col + col_span)}


def _normalized_axes_for_grid(
    descriptor: FigureDescriptor,
) -> tuple[list[tuple[AxisDescriptor, int]], int, int, bool]:
    """Return axes with safe zero-based positions, rows, columns, and whether
    their row_span/col_span options can be trusted.

    An axis normally fills exactly one grid cell. ``row_span``/``col_span`` in
    its options let it fill a rectangle of cells instead, so the figure is no
    longer limited to a uniform grid - e.g. one axis spanning the whole top
    row with two narrower axes below it. Positions and spans are validated
    together: if any axis would fall outside the grid or overlap another
    axis's footprint, every axis falls back to one cell each in a compact
    grid, exactly as an out-of-range axis_index already did. The returned
    ``spans_valid`` flag tells the caller whether that fallback happened -
    when it did, the stale row_span/col_span values in the (now repositioned)
    axes must be ignored rather than reapplied to their new, smaller cells.
    """
    axes = list(descriptor.axes or [])

    base_rows = max(1, int(descriptor.nrows or 1))
    base_cols = max(1, int(descriptor.ncols or 1))
    base_total = base_rows * base_cols

    if not axes:
        return [], base_rows, base_cols, True

    rows = base_rows
    cols = base_cols
    if base_total < len(axes):
        rows, cols = _compact_grid_for_axis_count(len(axes))

    used: set[tuple[int, int]] = set()
    valid_layout = True

    for axis_desc in axes:
        axis_index = int(axis_desc.index)
        if axis_index < 0 or axis_index >= rows * cols:
            valid_layout = False
            break
        row_span, col_span = _axis_span(axis_desc)
        footprint = _axis_footprint(
            axis_index=axis_index, row_span=row_span, col_span=col_span, rows=rows, cols=cols
        )
        if footprint is None or footprint & used:
            valid_layout = False
            break
        used |= footprint

    if valid_layout:
        return [(axis_desc, int(axis_desc.index)) for axis_desc in axes], rows, cols, True

    ordered_axes = sorted(
        axes,
        key=lambda axis_desc: (int(axis_desc.index), int(axis_desc.id)),
    )
    rows, cols = _compact_grid_for_axis_count(len(ordered_axes))
    normalized = [(axis_desc, index) for index, axis_desc in enumerate(ordered_axes)]

    applogger.warning(
        "Normalized stale axis indexes/spans for figure id=%r: grid %sx%s, axes=%s",
        descriptor.id,
        rows,
        cols,
        [(int(axis.id), int(axis.index), new_index) for axis, new_index in normalized],
    )

    return normalized, rows, cols, False


def _subplot_kwargs_for_axis(
    *,
    axis_desc: AxisDescriptor,
    first_ax: Any | None,
    created_by_id: dict[int, Any],
) -> dict[str, Any]:
    """Build add_subplot keyword arguments for one axis."""
    options = axis_desc.options if isinstance(axis_desc.options, dict) else {}
    subplot = options.get("subplot", {})
    subplot = subplot if isinstance(subplot, dict) else {}

    kwargs: dict[str, Any] = {}

    projection = subplot.get("projection") or options.get("projection")
    if isinstance(projection, str) and projection.strip():
        kwargs["projection"] = projection.strip()

    sharex = subplot.get("sharex", options.get("sharex"))
    sharey = subplot.get("sharey", options.get("sharey"))

    if isinstance(sharex, int) and sharex in created_by_id:
        kwargs["sharex"] = created_by_id[sharex]
    elif sharex is True and first_ax is not None:
        kwargs["sharex"] = first_ax

    if isinstance(sharey, int) and sharey in created_by_id:
        kwargs["sharey"] = created_by_id[sharey]
    elif sharey is True and first_ax is not None:
        kwargs["sharey"] = first_ax

    if bool(options.get("polar", False)):
        kwargs["projection"] = "polar"

    return kwargs


def _create_axes_grid(
    *,
    figure: Figure,
    descriptor: FigureDescriptor,
    axes_with_positions: list[tuple[AxisDescriptor, int]],
    rows: int,
    cols: int,
    respect_spans: bool = True,
) -> tuple[list[Any], set[Any]]:
    """Create all axes from a GridSpec using normalized positions.

    Returns the flat axes list and the set of axes on either side of a
    sharex/sharey pairing - the caller uses the latter for
    ``_clear_redundant_shared_axis_labels`` once every axis has been drawn
    and labelled.

    A GridSpec is used instead of the plain ``add_subplot(rows, cols, n)``
    numbering so that an axis whose options carry ``row_span``/``col_span``
    can occupy a rectangle of cells rather than exactly one - the mechanism
    that lets a figure use a layout other than a uniform grid.  A 1x1 span
    behaves exactly like the old numbered subplot, so every figure without
    spans renders identically to before.

    ``respect_spans=False`` forces every axis to one cell.  ``_normalized_
    axes_for_grid`` sets this when it had to fall back to a compact grid: the
    axes were repositioned into smaller cells that their original spans no
    longer fit, so honouring stale span values here would overlap axes again
    instead of resolving the conflict that triggered the fallback.
    """
    rows = max(1, int(rows))
    cols = max(1, int(cols))
    total = rows * cols

    axes_flat: list[Any] = [None] * total
    created_by_id: dict[int, Any] = {}
    first_ax: Any | None = None
    gridspec = figure.add_gridspec(rows, cols)
    # Every axis on either side of a sharex/sharey pairing, deferred to one
    # pass after the loop: an axis created early in the loop can still gain a
    # shared partner created later, so acting inside the loop could act on a
    # pairing that had not been discovered yet.
    shared_axes: set[Any] = set()

    for axis_desc, axis_index in axes_with_positions:
        axis_index = int(axis_index)
        if axis_index < 0 or axis_index >= total:
            applogger.error(
                "Axis id=%r normalized to invalid position %r for grid %sx%s.",
                axis_desc.id,
                axis_index,
                rows,
                cols,
            )
            return axes_flat, shared_axes

        axis_id = int(axis_desc.id)
        row = axis_index // cols
        col = axis_index % cols
        row_span, col_span = _axis_span(axis_desc) if respect_spans else (1, 1)
        # Defensive clamp: normalization already validates footprints for the
        # common case, but a span edited directly in a project file should
        # degrade to a smaller subplot rather than raise.
        row_span = max(1, min(row_span, rows - row))
        col_span = max(1, min(col_span, cols - col))

        kwargs = _subplot_kwargs_for_axis(
            axis_desc=axis_desc,
            first_ax=first_ax,
            created_by_id=created_by_id,
        )

        ax = figure.add_subplot(
            gridspec[row : row + row_span, col : col + col_span], **kwargs
        )
        axes_flat[axis_index] = ax
        created_by_id[axis_id] = ax

        if "sharex" in kwargs or "sharey" in kwargs:
            shared_axes.add(ax)
            shared_axes.update(kwargs[key] for key in ("sharex", "sharey") if key in kwargs)

        if first_ax is None:
            first_ax = ax

    # A shared-scale grid reads as one instrument split into panels, not
    # several unrelated charts that happen to agree - which needs the panels
    # touching, and the repeated tick labels between them gone, not just the
    # numbers agreeing. Matches Matplotlib's own convention for this (see the
    # sharex/sharey examples in the subplots_axes_and_figures gallery, which
    # pair sharex/sharey with gridspec_kw={"hspace": 0, "wspace": 0}).
    vertical_space, horizontal_space = _shared_axis_spacing(descriptor)
    _close_gaps_between_shared_neighbours(
        gridspec,
        axes_flat,
        vertical_space=vertical_space,
        horizontal_space=horizontal_space,
    )

    for ax in shared_axes:
        ax.label_outer()

    return axes_flat, shared_axes


#: Figure option keys for the gap left between shared, adjacent axes.
#: "Vertical" is the gap between stacked rows (Matplotlib's hspace) and
#: "horizontal" the gap between side-by-side columns (wspace), named for
#: the direction the gap runs rather than for the axis it separates.
#: 0.0 - flush, the Matplotlib gallery's own shared-axis convention - is
#: the default, which is what this did unconditionally before the two were
#: settable.
OPT_SHARED_VERTICAL_SPACE = "shared_vertical_space"
OPT_SHARED_HORIZONTAL_SPACE = "shared_horizontal_space"


def _shared_axis_spacing(descriptor: FigureDescriptor) -> tuple[float, float]:
    """Return this figure's (vertical, horizontal) shared-axis spacing."""
    options = descriptor.options if isinstance(descriptor.options, dict) else {}

    def _read(key: str) -> float:
        try:
            value = float(options.get(key, 0.0) or 0.0)
        except (TypeError, ValueError):
            return 0.0
        # Matplotlib reads these as a fraction of the average axis size; a
        # negative one would overlap the panels rather than space them.
        return max(0.0, value)

    return _read(OPT_SHARED_VERTICAL_SPACE), _read(OPT_SHARED_HORIZONTAL_SPACE)


def _close_gaps_between_shared_neighbours(
    gridspec: Any,
    axes_flat: list[Any],
    *,
    vertical_space: float = 0.0,
    horizontal_space: float = 0.0,
) -> None:
    """Set a GridSpec's row/column gap only where every neighbour agrees.

    A GridSpec has one wspace and one hspace for the whole grid, not a gap
    per row or column, so this cannot be "close the gap here but not there" -
    the earlier version zeroed both the moment *any* axis anywhere shared an
    axis with *any* other, which also closed the gap between two axes that
    happened to sit next to each other but shared nothing at all, as soon as
    the figure had a sharex/sharey pairing anywhere in it. Zeroing now
    requires every actually-adjacent pair - touching edges, in the row or
    column direction that gap runs - to be in the same Matplotlib sharex (for
    hspace) or sharey (for wspace) group; one adjacent pair that disagrees
    leaves that gap at the engine's own default rather than mislabel an
    unrelated pair as attached.

    "Adjacent" is read from each axis's own SubplotSpec rather than from the
    axis_index grid, so a row/col-spanning axis (Main + secondary, say) is
    handled the same as a plain 1x1 one.
    """
    axes = [ax for ax in axes_flat if ax is not None]

    vertical_pairs: list[tuple[Any, Any]] = []
    horizontal_pairs: list[tuple[Any, Any]] = []
    for i, a in enumerate(axes):
        spec_a = a.get_subplotspec()
        if spec_a is None:
            continue
        for b in axes[i + 1 :]:
            spec_b = b.get_subplotspec()
            if spec_b is None:
                continue
            cols_overlap = (
                spec_a.colspan.start < spec_b.colspan.stop
                and spec_b.colspan.start < spec_a.colspan.stop
            )
            rows_overlap = (
                spec_a.rowspan.start < spec_b.rowspan.stop
                and spec_b.rowspan.start < spec_a.rowspan.stop
            )
            touching_vertically = (
                spec_a.rowspan.stop == spec_b.rowspan.start
                or spec_b.rowspan.stop == spec_a.rowspan.start
            )
            touching_horizontally = (
                spec_a.colspan.stop == spec_b.colspan.start
                or spec_b.colspan.stop == spec_a.colspan.start
            )
            if cols_overlap and touching_vertically:
                vertical_pairs.append((a, b))
            if rows_overlap and touching_horizontally:
                horizontal_pairs.append((a, b))

    if vertical_pairs and all(
        a.get_shared_x_axes().joined(a, b) for a, b in vertical_pairs
    ):
        gridspec.update(hspace=vertical_space)
    if horizontal_pairs and all(
        a.get_shared_y_axes().joined(a, b) for a, b in horizontal_pairs
    ):
        gridspec.update(wspace=horizontal_space)


def _apply_shared_z_ranges(
    axes: list[AxisDescriptor], ax_by_id: dict[int, Any]
) -> None:
    """Use one common final Z range when any 3D axis enables Share Z.

    Matplotlib has no native ``sharez`` subplot argument. The checked axis is
    therefore the source, and its final Z limits are copied to every other 3D
    axis after renderers, scales and manual limits have run. If several axes
    are checked, the first checked 3D axis in descriptor order is the source.
    """
    source = next(
        (
            ax_by_id.get(int(desc.id))
            for desc in axes
            if isinstance(desc.options, dict)
            and bool(desc.options.get("sharez"))
            and hasattr(ax_by_id.get(int(desc.id)), "get_zlim")
        ),
        None,
    )
    if source is None:
        return
    try:
        shared_limits = source.get_zlim()
    except Exception:
        applogger.exception("Failed to read the shared Z range")
        return
    for desc in axes:
        ax = ax_by_id.get(int(desc.id))
        if ax is None or ax is source or not hasattr(ax, "set_zlim"):
            continue
        try:
            ax.set_zlim(*shared_limits)
        except Exception:
            applogger.exception("Failed to share the Z range for axis id=%r", desc.id)


def _clear_redundant_shared_axis_labels(shared_axes: set[Any]) -> None:
    """Blank the axis label text and title label_outer() leaves standing.

    label_outer() (called in _create_axes_grid, right after each axis is
    created) only strips tick *numbers*; the axis label text - "body mass
    (g)", "Count" - and the axis title are separate artists it never
    touches, and every panel in a shared row/column keeps repeating both.
    This runs after every axis has been drawn and given its label/title by
    _apply_axis_runtime_options, which is what a call this early would
    otherwise be overwritten by: blanked here, on exactly the same x/y
    edges label_outer() already used, so the one label left standing is the
    one whose tick numbers are also there.

    The title uses a different edge: it sits at the top of a panel, so it
    is kept only on the first row of each column rather than on the "outer"
    edge xlabel/ylabel use - Matplotlib's own shared-axis gallery example
    (subplots_axes_and_figures/shared_axis_demo) has no per-panel title at
    all, one suptitle only, which is part of why it reads as one attached
    instrument rather than several separate charts. Safe to clear: every
    shared-grid demo that gives each panel a distinguishing title also
    carries the same name in that panel's own legend, so nothing is lost,
    only the repetition.
    """
    for ax in shared_axes:
        spec = ax.get_subplotspec()
        if spec is None:
            continue
        if not spec.is_last_row():
            ax.set_xlabel("")
        if not spec.is_first_col():
            ax.set_ylabel("")
        if not spec.is_first_row():
            ax.set_title("")


# ----------------------------------------------------------------------
# Series loading
# ----------------------------------------------------------------------
#: Figure option key for the row-count above which a series query is
#: decimated before it is ever materialised in Python - see
#: _figure_downsample_threshold and SqliteRepo.downsampled_series_frame. A
#: figure that has never set it is decimated past DEFAULT_DOWNSAMPLE_THRESHOLD;
#: an explicit 0 turns it off.
OPT_DOWNSAMPLE_THRESHOLD = "downsample_threshold"

#: Applied when a figure descriptor carries no downsample_threshold of its
#: own. Keeps a redraw quick on a large series while leaving the shape of
#: any ordinary curve untouched (it only decimates *past* this many points).
DEFAULT_DOWNSAMPLE_THRESHOLD = get_constant("default_downsample_threshold", 1_000)

#: Chart types whose renderer needs a *complete* x/y/z grid (pivot_to_grid,
#: app/charts/grids.py) and refuses anything less. Row-based downsampling
#: (SqliteRepo.downsampled_series_frame) keeps one row out of every stride
#: after ORDER BY x - fine for an ordinary curve, but on a grid table an odd
#: number of rows per x-block shifts which y-values survive from one block
#: to the next, so the surviving rows are no longer a full Cartesian product
#: of x and y. pivot_to_grid then rightly refuses them, and the renderer
#: draws nothing instead of the smaller-but-complete grid it should. Grid
#: datasets are also typically far smaller than the row counts downsampling
#: exists for, so these chart types simply skip it rather than decimating by
#: unique x/y instead - not worth the extra machinery yet.
_GRID_REQUIRED_CHART_TYPES = frozenset({"Surface Plot", "Contour Plot"})

#: Charts where every point is a datum - an outlier, a member of a cluster -
#: rather than a sample of a curve: thinned out only past a far higher count,
#: since a scatter of a few thousand points draws quickly anyway.
_POINT_CHART_TYPES = frozenset({"Scatter Plot"})
POINT_DOWNSAMPLE_THRESHOLD = get_constant("point_downsample_threshold", 20_000)


def _figure_downsample_threshold(descriptor: FigureDescriptor) -> int:
    """Return this figure's configured downsample threshold, 0 if disabled."""
    options = descriptor.options if isinstance(descriptor.options, dict) else {}
    raw = options.get(OPT_DOWNSAMPLE_THRESHOLD, DEFAULT_DOWNSAMPLE_THRESHOLD)
    try:
        threshold = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_DOWNSAMPLE_THRESHOLD
    return max(0, threshold)


def _build_series_data_list(
    *,
    repo: SqliteRepo,
    axis_desc: AxisDescriptor,
    downsample_threshold: int = 0,
) -> list[SeriesData]:
    """Build the list of visible series for one axis."""
    output: list[SeriesData] = []

    for series_desc in list(axis_desc.series or []):
        style = _series_style(series_desc)
        if not bool(style.get("visible", True)):
            continue

        df = _load_series_df(
            repo=repo, series_desc=series_desc, downsample_threshold=downsample_threshold
        )
        roles = series_desc.roles if isinstance(series_desc.roles, dict) else {}
        output.append(
            SeriesData(
                name=str(series_desc.name or ""),
                df=df,
                style=style,
                roles=dict(roles),
            )
        )

    return output


def _draw_band(ax: Any, series: SeriesData) -> None:
    """Fill between the series' ``y`` and ``y2`` columns over ``x``."""
    roles, style, frame = series.roles, series.style, series.df
    columns = [str(roles.get(role) or role) for role in ("x", "y", "y2")]
    if not all(column in frame for column in columns):
        applogger.warning("Band %r needs x, y and y2 columns; not drawn.", series.name)
        return
    x, low, high = (
        to_numbers(frame[column]).to_numpy(dtype=float) for column in columns
    )
    keep = np.isfinite(x) & np.isfinite(low) & np.isfinite(high)
    order = np.argsort(x[keep], kind="stable")
    ax.fill_between(
        x[keep][order],
        low[keep][order],
        high[keep][order],
        color=style.get("color") or "0.45",
        alpha=float(style.get("alpha", 0.2)),
        linewidth=0,
        label=style.get("label") or series.name,
        zorder=float(style.get("zorder", 0.8)),
    )


def _load_series_df(
    *,
    repo: SqliteRepo,
    series_desc: SeriesDescriptor,
    downsample_threshold: int = 0,
) -> SeriesFrame:
    """Load one series' data from its SQL query.

    Goes through ``SqliteRepo.series_frame`` (or ``downsampled_series_frame``
    when a threshold is set) so repeated renders of an unchanged database are
    served from cache: SQLite row materialisation is ~89 % of the render
    cost and cannot be optimised away in pure Python. Kept name-compatible
    with its longtime callers even though it no longer returns a DataFrame -
    see ``app.data.series_frame`` for what changed and why.
    """
    sql = str(series_desc.sql_query or "").strip()
    if not sql:
        applogger.error(
            "SQL query is empty for series id=%r name=%r.",
            series_desc.id,
            series_desc.name,
        )
        return SeriesFrame()

    try:
        if downsample_threshold > 0:
            return repo.downsampled_series_frame(sql, threshold=downsample_threshold)
        return repo.series_frame(sql)
    except Exception:
        applogger.exception(
            "Failed to load SQL data for series id=%r name=%r.",
            series_desc.id,
            series_desc.name,
        )
        return SeriesFrame()


def _series_style(series_desc: SeriesDescriptor) -> dict[str, Any]:
    """Return a normalized series style dictionary."""
    style = series_desc.options
    if isinstance(style, dict):
        return dict(style)
    return {}


# ----------------------------------------------------------------------
# Figure / axis options
# ----------------------------------------------------------------------
def _apply_figure_options(figure: Figure, fig_desc: FigureDescriptor) -> None:
    """Apply figure-level options that do not own physical metrics.

    Figure face and edge colours are re-read from the active rcParams here.
    Why: Matplotlib freezes those two on the Figure at construction time, and
    ChartPanel constructs its Figure once and reuses it for the life of the
    panel, so ``figure.facecolor`` in a user's style file would otherwise have
    no visible effect at all.
    """
    options = fig_desc.options if isinstance(fig_desc.options, dict) else {}

    try:
        figure.set_facecolor(plt.rcParams["figure.facecolor"])
        figure.set_edgecolor(plt.rcParams["figure.edgecolor"])
    except Exception:
        applogger.exception("Failed to apply figure colours from rcParams")

    try:
        figure.set_frameon(bool(options.get("frameon", True)))
    except Exception:
        applogger.exception("Failed to apply figure frameon")

    suptitle = options.get("suptitle")
    if isinstance(suptitle, str) and suptitle.strip():
        figure.suptitle(suptitle.strip())


#: Allowed range for the "font_scale" option of a figure and of an axis.
FONT_SCALE_RANGE: tuple[float, float] = (0.5, 3.0)


def font_scale_option(options: Any) -> float:
    """The "font_scale" of a figure's or an axis's options, clamped; 1.0 when unset."""
    try:
        value = float((options or {}).get("font_scale", 1.0))
    except (TypeError, ValueError, AttributeError):
        return 1.0
    low, high = FONT_SCALE_RANGE
    return min(max(value, low), high) if value == value else 1.0


def _scale_axes_text(ax: Any, factor: float) -> None:
    """Multiply the size of every piece of text an axes draws by *factor*."""
    texts = [ax.title, getattr(ax, "_left_title", None), getattr(ax, "_right_title", None)]
    for axis_name in ("xaxis", "yaxis", "zaxis"):
        axis = getattr(ax, axis_name, None)
        if axis is None:
            continue
        texts.append(axis.label)
        texts.append(axis.get_offset_text())
        for which in ("major", "minor"):
            ticks = axis.get_major_ticks() if which == "major" else axis.get_minor_ticks()
            if ticks:
                size = ticks[0].label1.get_fontsize()
                axis.set_tick_params(which=which, labelsize=size * factor)
    texts.extend(ax.texts)
    legend = ax.get_legend()
    if legend is not None:
        texts.extend(legend.get_texts())
        texts.append(legend.get_title())
    for text in texts:
        if text is not None:
            text.set_fontsize(text.get_fontsize() * factor)


def _apply_font_scale(
    figure: Figure,
    descriptor: FigureDescriptor,
    axes: list[AxisDescriptor],
    ax_by_id: dict[int, Any],
) -> None:
    """Grow or shrink all text: the figure's "font_scale" times each axis's own.

    Applied once per render, on a figure that render_figure_from_descriptor
    has just cleared and rebuilt, so the factor never compounds. Axes the
    descriptor does not know (a colorbar's) take the figure's factor.
    """
    figure_factor = font_scale_option(descriptor.options)
    known: set[int] = set()
    for axis_desc in axes:
        ax = ax_by_id.get(int(axis_desc.id))
        if ax is None or id(ax) in known:
            continue
        known.add(id(ax))
        factor = figure_factor * font_scale_option(axis_desc.options)
        if abs(factor - 1.0) > 1e-9:
            try:
                _scale_axes_text(ax, factor)
            except Exception:
                applogger.exception("Failed to scale the fonts of axis id=%r", axis_desc.id)
    if abs(figure_factor - 1.0) <= 1e-9:
        return
    for ax in figure.axes:
        if id(ax) not in known:
            _scale_axes_text(ax, figure_factor)
    # figure.texts already holds the suptitle; each text is scaled once.
    for text in {id(t): t for t in figure.texts}.values():  # pyright: ignore[reportAttributeAccessIssue]
        text.set_fontsize(text.get_fontsize() * figure_factor)


def _apply_axis_runtime_options(ax: Any, axis_desc: AxisDescriptor) -> None:
    """Apply axis options after the chart renderer has drawn the axis."""
    options = axis_desc.options if isinstance(axis_desc.options, dict) else {}

    title = options.get("title") or options.get("label") or axis_desc.title
    if isinstance(title, str) and title.strip():
        ax.set_title(title.strip())

    xlabel = options.get("x_label", axis_desc.x_label)
    ylabel = options.get("y_label", axis_desc.y_label)
    zlabel = options.get("z_label", axis_desc.z_label)

    # Only non-empty labels are applied.  Why: some renderers set a meaningful
    # default label themselves (the histogram labels its count axis), and an
    # empty descriptor field means "nothing specified", not "clear it".
    if isinstance(xlabel, str) and xlabel.strip():
        ax.set_xlabel(xlabel)
    if isinstance(ylabel, str) and ylabel.strip():
        ax.set_ylabel(ylabel)
    if isinstance(zlabel, str) and zlabel.strip() and hasattr(ax, "set_zlabel"):
        ax.set_zlabel(zlabel)

    # A renderer that is a drawing rather than a plot (the fishbone) marks
    # its axes so the frame and ticks it switched off stay off.
    if bool(options.get("hide_axis", options.get("hidden", False))) or getattr(ax, "_dhub_axis_off", False):
        ax.set_axis_off()
    else:
        ax.set_axis_on()

    # Order is not free here:
    #   scale -> limits -> inversion.
    # set_xscale() resets the view interval, so it has to run before the limits
    # are applied, and set_xlim() rewrites the direction, so inversion has to
    # run after them.  Applying these in any other order silently loses one of
    # the three settings.
    _apply_scales(ax, options)
    _apply_limits(ax, options)
    _apply_inversion(ax, options)

    _apply_ticks(ax, options)
    _apply_grid(ax, options)
    _apply_spines(ax, options)
    _apply_pickradius(ax, options)
    _apply_aspect_options(ax, options)


# Matplotlib scales that need no extra arguments beyond the base.
SUPPORTED_AXIS_SCALES: tuple[str, ...] = ("linear", "log", "symlog", "logit")


def _apply_scales(ax: Any, options: dict[str, Any]) -> None:
    """Apply per-axis scale, with a log base where the scale accepts one.

    z is included and costs nothing on a 2D axes: ``set_zscale`` is not there
    to be found, and the getattr below already skips a setter that is missing.
    """
    for axis_name, setter_name in (
        ("x", "set_xscale"),
        ("y", "set_yscale"),
        ("z", "set_zscale"),
    ):
        raw = options.get(f"{axis_name}_scale", "linear")
        scale = str(raw or "linear").strip().lower()
        if scale == "linear":
            continue

        if scale not in SUPPORTED_AXIS_SCALES:
            applogger.warning("Unknown %s scale: %r", axis_name, raw)
            continue

        setter = getattr(ax, setter_name, None)
        if setter is None:
            continue

        kwargs: dict[str, Any] = {}
        if scale in {"log", "symlog"}:
            base = options.get(f"{axis_name}_scale_base", options.get("scale_base"))
            if base is not None:
                try:
                    base_value = float(base)
                    if base_value > 1.0:
                        kwargs["base"] = base_value
                except (TypeError, ValueError):
                    applogger.warning("Invalid log base for %s axis: %r", axis_name, base)
        if scale == "symlog":
            threshold = options.get(f"{axis_name}_linthresh", options.get("linthresh"))
            if threshold is not None:
                try:
                    threshold_value = float(threshold)
                    if threshold_value > 0.0:
                        kwargs["linthresh"] = threshold_value
                except (TypeError, ValueError):
                    applogger.warning("Invalid linthresh for %s axis: %r", axis_name, threshold)

        try:
            setter(scale, **kwargs)
        except Exception:
            applogger.exception("Failed to set %s scale to %r", axis_name, scale)


def _apply_inversion(ax: Any, options: dict[str, Any]) -> None:
    """Point each axis in the requested direction.

    Uses the absolute ``set_inverted`` rather than ``invert_xaxis``: the latter
    toggles, so re-rendering an already inverted axis would flip it back.

    ``zaxis`` is looked up rather than named, because a 2D axes has none - and
    "invert z" on a scatter plot has to be a setting that does nothing, not
    one that raises.
    """
    axes_objects = [("x", ax.xaxis), ("y", ax.yaxis)]
    z_axis = getattr(ax, "zaxis", None)
    if z_axis is not None:
        axes_objects.append(("z", z_axis))

    for axis_name, axis_object in axes_objects:
        wanted = bool(options.get(f"invert_{axis_name}", False))
        try:
            if bool(axis_object.get_inverted()) != wanted:
                axis_object.set_inverted(wanted)
        except Exception:
            applogger.exception("Failed to set %s axis direction", axis_name)


def _wanted_minor_ticks(options: dict[str, Any], axis: str) -> bool | None:
    """Return True to force minor ticks on *axis*, False to remove them, None
    to leave the style sheet alone.

    A minor grid counts as wanting them: a grid on ticks that do not exist
    draws nothing, which reads as a broken setting rather than an empty one.
    """
    setting = axis_options.tick_setting(options, axis, "minor")
    if setting == axis_options.OFF:
        return False
    if setting != axis_options.AUTO:
        return True

    grid = axis_options.grid_setting(options, axis, "minor")
    if grid not in (axis_options.AUTO, axis_options.OFF):
        return True
    return None


def _apply_minor_ticks(ax: Any, options: dict[str, Any]) -> None:
    """Turn minor ticks on or off per axis.

    ``minorticks_on`` is per *axes* and picks the locator that suits each
    scale - AutoMinorLocator is simply wrong on a log axis - so the way to get
    them on one axis only is to switch both on and then take back the one that
    was asked to stay off.
    """
    wanted = {axis: _wanted_minor_ticks(options, axis) for axis in axis_options.AXES}
    if any(state is True for state in wanted.values()):
        try:
            ax.minorticks_on()
        except Exception:
            applogger.exception("Failed to enable minor ticks")

    for axis, state in wanted.items():
        if state is not False:
            continue
        axis_object = ax.xaxis if axis == "x" else ax.yaxis
        try:
            axis_object.set_minor_locator(NullLocator())
        except Exception:
            applogger.exception("Failed to remove minor ticks from %s", axis)


def _apply_ticks(ax: Any, options: dict[str, Any]) -> None:
    """Apply the four tick settings, then tick size and label rotation."""
    _apply_minor_ticks(ax, options)

    for axis in axis_options.AXES:
        # tick_params(axis="z") is a ValueError on a 2D axes, and every 2D
        # chart would log one per tick class. Skipped instead: the setting is
        # kept in the descriptor for a projection that may yet become 3d.
        if axis == "z" and not hasattr(ax, "zaxis"):
            continue

        for which in axis_options.WHICH:
            setting = axis_options.tick_setting(options, axis, which)
            if setting == axis_options.AUTO:
                continue

            if setting == axis_options.OFF:
                # Length zero rather than hiding the labels with them: "no
                # ticks" is about the marks, and a chart with no numbers on it
                # is a different request.
                _tick_params(ax, axis=axis, which=which, length=0.0)
                continue

            if setting != axis_options.ON:
                _tick_params(ax, axis=axis, which=which, direction=setting)

    _apply_tick_sizes(ax, options)


def _apply_tick_sizes(ax: Any, options: dict[str, Any]) -> None:
    """Each coordinate's tick length and label rotation, major and minor apart.

    Keys: ``{axis}_tick_length`` / ``{axis}_tick_rotation`` for the major
    ticks, ``{axis}_minor_tick_length`` / ``{axis}_minor_tick_rotation`` for
    the minor ones. A figure saved before them has one ``tick_length`` for
    every tick and ``x_tick_rotation`` for the x labels; those still apply.
    """
    legacy_length = options.get("tick_length")
    for axis in axis_options.AXES:
        if axis == "z" and not hasattr(ax, "zaxis"):
            continue
        for which, prefix in (("major", f"{axis}_"), ("minor", f"{axis}_minor_")):
            length = options.get(f"{prefix}tick_length")
            if length is None and which == "major":
                length = legacy_length
            if length is not None:
                try:
                    _tick_params(ax, axis=axis, which=which, length=float(length))
                except (TypeError, ValueError):
                    applogger.warning("Invalid %s %s tick length: %r", axis, which, length)
            rotation = options.get(f"{prefix}tick_rotation")
            if rotation in (None, 0, 0.0):
                continue
            try:
                angle = float(rotation)
            except (TypeError, ValueError):
                applogger.warning("Invalid %s %s tick rotation: %r", axis, which, rotation)
                continue
            labels = getattr(ax, f"get_{axis}ticklabels")(minor=which == "minor")
            for label in labels:
                label.set_rotation(angle)
                # Rotated x labels overlap the axis unless they are anchored
                # at the end that stays next to the tick.
                if axis == "x":
                    label.set_horizontalalignment("right")


def _tick_params(ax: Any, **kwargs: Any) -> None:
    """Call ``tick_params`` and report a failure rather than raising."""
    try:
        ax.tick_params(**kwargs)
    except Exception:
        applogger.exception("Failed to apply tick parameters: %r", kwargs)


def _apply_grid(ax: Any, options: dict[str, Any]) -> None:
    """Apply the per-axis, per-class grid settings.

    Each one is applied, including the ones that say off: the previous
    version returned early when the grid was not wanted, so it could only ever
    add a grid. Against a style sheet with ``axes.grid: True`` - which the
    shipped ones have - that made "no grid" impossible to express.

    A 3D axes goes elsewhere entirely; see :func:`_apply_grid_3d`.
    """
    if hasattr(ax, "zaxis"):
        _apply_grid_3d(ax, options)
        return

    for axis in axis_options.AXES:
        if axis == "z":
            continue
        for which in axis_options.WHICH:
            setting = axis_options.grid_setting(options, axis, which)
            if setting == axis_options.AUTO:
                continue

            try:
                if setting == axis_options.OFF:
                    ax.grid(False, which=which, axis=axis)
                elif setting == axis_options.ON:
                    ax.grid(True, which=which, axis=axis)
                else:
                    ax.grid(True, which=which, axis=axis, linestyle=setting)
            except Exception:
                applogger.exception(
                    "Failed to apply the %s %s grid", axis, which
                )


def _apply_grid_3d(ax: Any, options: dict[str, Any]) -> None:
    """Apply one grid setting to a 3D axes, which is all it has.

    ``Axes3D.grid`` is ``grid(visible=True, **kwargs)``: the axis and the tick
    class are accepted and discarded, and the single flag draws or hides all
    three panes together. Passing the six settings through the 2D loop
    therefore did not do nothing - it did something misleading, applying
    whichever combination happened to be last.

    So the six are resolved into the one answer Matplotlib can take. The first
    setting that is not "from the style", read x then y then z and major
    before minor, decides for the box; a line style decides as "on", because
    Matplotlib will not take a style here either. When every setting is AUTO
    the style sheet keeps charge, which is what AUTO means everywhere else.
    """
    decided: str | None = None
    for axis in axis_options.AXES:
        for which in axis_options.WHICH:
            setting = axis_options.grid_setting(options, axis, which)
            if setting != axis_options.AUTO:
                decided = setting
                break
        if decided is not None:
            break

    if decided is None:
        return

    visible = decided != axis_options.OFF
    try:
        ax.grid(visible)
    except Exception:
        applogger.exception("Failed to apply the 3D grid")
        return

    if decided not in (axis_options.ON, axis_options.OFF):
        applogger.info(
            "A 3D axes has one grid for the whole box, so the %r line style "
            "was applied as simply 'on'.",
            decided,
        )


def _apply_spines(ax: Any, options: dict[str, Any]) -> None:
    """Show or hide individual spines."""
    spines = getattr(ax, "spines", None)
    if spines is None:
        return

    for name in ("top", "right", "bottom", "left"):
        key = f"hide_spine_{name}"
        if key not in options:
            continue
        try:
            spines[name].set_visible(not bool(options.get(key)))
        except Exception:
            applogger.exception("Failed to set visibility of the %s spine", name)


def _apply_limits(ax: Any, options: dict[str, Any]) -> None:
    """Apply the view range: the xlim/ylim pairs, then the manual limits.

    The pairs come first because the mode is the later, finer answer: it says
    which axis is manual at all, and either end of a manual axis may be left
    empty to keep that end automatic - ``set_xlim`` takes None for exactly
    that.
    """
    xlim = options.get("xlim")
    ylim = options.get("ylim")

    if isinstance(xlim, (list, tuple)) and len(xlim) == 2:
        try:
            ax.set_xlim(float(xlim[0]), float(xlim[1]))
        except (TypeError, ValueError):
            applogger.warning("Invalid xlim: %r", xlim)

    if isinstance(ylim, (list, tuple)) and len(ylim) == 2:
        try:
            ax.set_ylim(float(ylim[0]), float(ylim[1]))
        except (TypeError, ValueError):
            applogger.warning("Invalid ylim: %r", ylim)

    for axis in axis_options.LIMIT_AXES:
        setter = getattr(ax, f"set_{axis}lim", None)
        if setter is None:
            # A 2D axes and a z limit: stored, ignored, and kept - switching
            # the projection to 3d later must find the range still there.
            continue

        if axis_options.is_automatic(options, axis):
            continue

        low = axis_options.manual_limit(options, axis, "min")
        high = axis_options.manual_limit(options, axis, "max")
        if low is None and high is None:
            continue

        if low is not None and high is not None:
            if low == high:
                applogger.warning(
                    "Ignoring the manual %s limits: both ends are %g", axis, low
                )
                continue
            if low > high:
                # Reversed limits invert the axis, which has its own control
                # and would then be applied twice. Order them and say so.
                applogger.warning(
                    "Manual %s limits were reversed (%g, %g); using them in "
                    "order. Use the axis direction option to invert.",
                    axis,
                    low,
                    high,
                )
                low, high = high, low

        try:
            setter(low, high)
        except Exception:
            applogger.exception("Failed to set the manual %s limits", axis)


def _apply_pickradius(ax: Any, options: dict[str, Any]) -> None:
    """Apply optional pickradius if supported by the axis."""
    pickradius = options.get("pickradius")
    if pickradius is None:
        return

    try:
        ax.pickradius = float(pickradius)
    except (AttributeError, TypeError, ValueError):
        applogger.info("Ignoring unsupported pickradius=%r", pickradius)


def _apply_aspect_options(ax: Any, options: dict[str, Any]) -> None:
    """Apply optional aspect and adjustable axis options."""
    aspect = options.get("aspect")
    if aspect is not None:
        try:
            if isinstance(aspect, str):
                ax.set_aspect(aspect.strip())
            else:
                ax.set_aspect(float(aspect))
        except (TypeError, ValueError):
            applogger.warning("Invalid axis aspect: %r", aspect)

    adjustable = options.get("adjustable")
    if isinstance(adjustable, str) and adjustable.strip():
        try:
            ax.set_adjustable(adjustable.strip())
        except ValueError:
            applogger.warning("Invalid axis adjustable value: %r", adjustable)


def _apply_layout(figure: Figure, fig_desc: FigureDescriptor) -> None:
    """Apply final figure layout.

    Figure option example:
        {
            "layout_mode": "none",
            "margins": {
                "left": 0.04,
                "right": 0.99,
                "bottom": 0.06,
                "top": 0.97,
                "wspace": 0.08,
                "hspace": 0.08
            }
        }
    """
    options = fig_desc.options if isinstance(fig_desc.options, dict) else {}
    # A figure that names no engine gets "tight": forgiving on the simple
    # figures most charts are, and needs no per-figure margins block.
    raw_mode = str(options.get("layout_mode", "tight") or "tight").strip().lower()

    if raw_mode == "constrained":
        _set_layout_engine_safely(figure, "constrained")
        return

    if raw_mode == "compressed":
        _set_layout_engine_safely(figure, "compressed")
        return

    if raw_mode == "tight":
        _set_layout_engine_safely(figure, "tight")
        return

    _set_layout_engine_safely(figure, "none")
    _apply_subplot_margins(figure, options)


def _apply_subplot_margins(figure: Figure, options: dict[str, Any]) -> None:
    """Apply explicit subplot margins for layout_mode='none'."""
    margins = options.get("margins")
    margins = margins if isinstance(margins, dict) else {}

    left = _float_option(margins, "left", 0.04)
    right = _float_option(margins, "right", 0.99)
    bottom = _float_option(margins, "bottom", 0.06)
    top = _float_option(margins, "top", 0.97)
    wspace = _float_option(margins, "wspace", 0.08)
    hspace = _float_option(margins, "hspace", 0.08)

    try:
        figure.subplots_adjust(
            left=left,
            right=right,
            bottom=bottom,
            top=top,
            wspace=wspace,
            hspace=hspace,
        )
    except Exception:
        applogger.exception("Failed to apply subplot margins")


def _normalize_axes_fill_policy(figure: Figure, fig_desc: FigureDescriptor) -> None:
    """Prevent fixed-aspect axes from shrinking their axes box by default."""
    fig_options = fig_desc.options if isinstance(fig_desc.options, dict) else {}
    preserve_all = bool(fig_options.get("preserve_aspect_box", False))

    # Matched by the id tagged onto each axes in render_figure_from_descriptor,
    # not by position: a twin axis is created after every base axis, so
    # figure.axes and fig_desc.axes no longer share one order once a figure
    # has any twins at all.
    options_by_id = {
        int(axis_desc.id): axis_desc.options if isinstance(axis_desc.options, dict) else {}
        for axis_desc in list(fig_desc.axes or [])
    }

    for ax in list(figure.axes):
        try:
            axis_id = getattr(ax, "_dhub_axis_id", None)
            axis_options = options_by_id.get(axis_id, {}) if axis_id is not None else {}
            if preserve_all or bool(axis_options.get("preserve_aspect_box", False)):
                continue

            if ax.get_aspect() != "auto" and ax.get_adjustable() == "box":
                ax.set_adjustable("datalim")

            ax.set_anchor("C")
        except Exception:
            applogger.exception("Failed to normalize axes fill policy")


def _set_layout_engine_safely(figure: Figure, mode: LayoutMode) -> None:
    """Set Matplotlib layout engine without letting layout failure stop render.

    ``mode == "none"`` passes Python ``None``, not the string ``"none"``: the
    two are not equivalent past this call, only right now. The string leaves
    a ``PlaceHolderLayoutEngine`` in place - matplotlib's own marker that
    *some* layout engine used to be set - and ``subplots_adjust`` refuses to
    touch a figure carrying one, forever, no matter how many times "none" is
    set again. Only actual ``None`` clears the engine outright, which is what
    switching to manual spacing needs: this figure's chart tab keeps the same
    Matplotlib Figure across every redraw, so a figure that had ever used
    "constrained" would otherwise have its manual margins silently ignored
    from that point on.
    """
    try:
        figure.set_layout_engine(None if mode == "none" else mode)  # pyright: ignore[reportArgumentType]
    except Exception:
        applogger.exception("Failed to set Matplotlib layout engine: %s", mode)


def _float_option(options: dict[str, Any], key: str, default: float) -> float:
    """Read a float option safely."""
    value = options.get(key, default)
    try:
        return float(value)
    except (TypeError, ValueError):
        applogger.warning("Invalid float option %s=%r, using %r", key, value, default)
        return default
