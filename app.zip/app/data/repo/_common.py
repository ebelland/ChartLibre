"""The vocabulary the repository is built out of.

Split out of ``sqlite_repo`` so the pieces of that module - saved queries,
maintenance, and whatever follows them - can be modules of their own
without importing the class they are part of (todo.txt N-5). Nothing here
knows about SqliteRepo: it is the SQL-shaped helpers, the two small result
types, and the decorator every method that touches the connection wears.

``sqlite_repo`` re-exports all of it, so ``from app.data.sqlite_repo import
DatabaseReport`` keeps working - the split is meant to be invisible from
outside.
"""
from __future__ import annotations

import json
import re
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from functools import wraps
from typing import TYPE_CHECKING, Any, ClassVar, Mapping

from app.data.data_source import is_identifier, quote_identifier
from app.logs.logger import applogger


def ensure_connection_wrapper(func):
    ''' This wrapper ensures that database to be connected'''
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if not self._is_connected or self._con is None:
            self._connect()
        if not self._is_connected or self._con is None:
            applogger.critical("No active connection")
        return func(self, *args, **kwargs)
    return wrapper


def descriptor_write_wrapper(func):
    """Mark a write as touching only descriptor tables, not data tables.

    Every write in DescriptorsMixin targets ``__figure_descriptors__``,
    ``__axis_descriptors__`` or ``__series_descriptors__`` - never a table a
    series query's own SQL selects from - so it cannot change what a cached
    SeriesFrame means. ``SqliteRepo._database_stamp`` folds
    ``Connection.total_changes`` into the stamp that invalidates the whole
    series cache; without this, editing one axis's label cleared the cached
    series of every axis of every open figure, because ``total_changes``
    counts this UPDATE exactly like it counts a real data edit. Subtracting
    the delta here (via ``_series_cache_metadata_changes``) keeps the stamp
    honest about everything else, without asking the invalidation itself to
    trust any hand-kept bookkeeping: a write this decorator is missing from
    only over-invalidates, same as before, never under-invalidates.

    Stack it inside ``@ensure_connection_wrapper`` (that one runs first, so
    the connection this reads ``total_changes`` from is guaranteed to
    exist)::

        @ensure_connection_wrapper
        @descriptor_write_wrapper
        def set_axis_options(self, ...): ...

    Reentrant by depth, not by measuring every call: ``delete_figure`` calls
    ``delete_axis`` calls ``delete_series``, all three wrapped, and
    ``total_changes`` already accounts for the inner calls' rows by the time
    the outer one finishes. Only the outermost call takes a "before" reading
    and folds the total delta in on the way back out - an inner call that
    measured its own slice too would double-count those rows, so
    ``_series_cache_metadata_changes`` could out-grow ``total_changes``
    itself and, on some future write, the stamp could go *backwards* onto a
    value already sitting in the cache - stale data served as current.
    """
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        con = self._con
        if con is None:
            return func(self, *args, **kwargs)
        entering = self._series_cache_metadata_write_depth == 0
        before = con.total_changes if entering else 0
        self._series_cache_metadata_write_depth += 1
        try:
            return func(self, *args, **kwargs)
        finally:
            self._series_cache_metadata_write_depth -= 1
            if entering:
                self._series_cache_metadata_changes += con.total_changes - before
    return wrapper

# Regex: SQL statement that returns rows (SELECT, WITH, PRAGMA, EXPLAIN)
_RETURNS_ROWS_RE = re.compile(r"^\s*(select|with|pragma|explain)\b", re.IGNORECASE)

# A saved query exists to put rows on a chart, so it must only ever read.
#
# "Returns rows" is a weaker property than "changes nothing", and the two are
# easy to confuse: PRAGMA returns rows and also writes (``PRAGMA user_version =
# 5``), and SQLite lets a WITH clause introduce a DELETE or an UPDATE, so
# ``WITH x AS (SELECT 1) DELETE FROM readings`` passes a leading-keyword test
# while emptying a table.  Saved queries therefore get this stricter check
# rather than _RETURNS_ROWS_RE.
_SAVED_QUERY_OPENER_RE = re.compile(r"^\s*(select|with)\b", re.IGNORECASE)

#: Statement keywords that write.  Checked against the whole statement, after
#: comments and string literals are removed, because they can appear well past
#: the opening keyword.
#: ``replace`` is deliberately absent: it is also SQLite's string function, and
#: ``SELECT replace(name, 'a', 'b')`` is perfectly read-only.  The statement
#: form is caught by _REPLACE_INTO_RE instead.
#: Permissive on purpose (todo N-05): the point is that nothing a person
#: types can change or damage the database, not to police what they read -
#: so PRAGMA reads, ATTACH, transactions and every function stay allowed.
_WRITE_KEYWORDS: frozenset[str] = frozenset(
    {"alter", "create", "delete", "drop", "insert", "reindex", "update", "vacuum"}
)

_REPLACE_INTO_RE = re.compile(r"\breplace\s+into\b", re.IGNORECASE)

_SQL_COMMENT_RE = re.compile(r"--[^\n]*|/\*.*?\*/", re.DOTALL)
_SQL_LITERAL_RE = re.compile(r"'(?:[^']|'')*'|\"(?:[^\"]|\"\")*\"|\[[^\]]*\]|`[^`]*`")
_SQL_WORD_RE = re.compile(r"[A-Za-z_][A-Za-z_0-9]*")


def _sql_without_comments_and_literals(sql: str) -> str:
    """Return ``sql`` with comments, quoted strings and quoted names removed.

    Keyword matching has to happen on code, not on content: a perfectly
    read-only query can carry the word "delete" inside a string literal or a
    column alias, and refusing that would be a false alarm.  Removing both
    first means the keyword scan only ever sees SQL.
    """
    return _SQL_LITERAL_RE.sub(" ", _SQL_COMMENT_RE.sub(" ", sql))


def is_read_only_select(sql: str) -> tuple[bool, str]:
    """Return ``(ok, reason)`` for whether ``sql`` only reads data.

    ``reason`` is empty when ok.  Trailing semicolons are tolerated, but an
    actual second statement is not: ``SELECT 1; DELETE FROM t`` is rejected
    rather than silently truncated to its harmless first half.
    """
    text = str(sql or "").strip()
    if not text:
        return False, "The query is empty."

    code = _sql_without_comments_and_literals(text).strip()

    # Tolerate trailing semicolons and whitespace, then refuse anything that
    # still has a statement separator with SQL after it.
    body = code.rstrip().rstrip(";").rstrip()
    if ";" in body:
        return False, "Only a single statement can be saved as a query."

    if not _SAVED_QUERY_OPENER_RE.match(body):
        return False, "A saved query must be a SELECT (or WITH) statement."

    found = {word.lower() for word in _SQL_WORD_RE.findall(body)} & _WRITE_KEYWORDS
    if _REPLACE_INTO_RE.search(body):
        found = found | {"replace"}

    if found:
        listed = ", ".join(sorted(found))
        return False, (
            f"A saved query must only read data, but this one uses: {listed}."
        )

    return True, ""


#: user.json key: set to false to switch the SQL guard off entirely.
SQL_GUARD_KEY: str = "sql_guard"


def sql_guard_enabled() -> bool:
    """Whether the SQL guard is on (the default); user.json "sql_guard": false turns it off.

    The guard acts only where a person writes SQL - saving a query, editing
    a series' SQL, an expression, a query on another database - and when a
    project is opened; never while charts are drawn.
    """
    from app.utils.config import get_value  # late: config imports the logger stack

    return bool(get_value(SQL_GUARD_KEY, True))


def ensure_read_only_select(sql: str) -> None:
    """Raise ValueError unless *sql* is a single statement that only reads."""
    if not sql_guard_enabled():
        return
    ok, reason = is_read_only_select(sql)
    if not ok:
        raise ValueError(reason)


def check_sql_expression(expression: str) -> None:
    """Raise ValueError unless *expression* is a single SQL expression.

    For the places where a person types a fragment that the application
    splices into a larger statement ("Add column from SQL expression"): no
    statement separator, and none of the keywords that write. A subquery
    that reads is allowed.
    """
    code = _sql_without_comments_and_literals(str(expression or "")).strip()
    if not code:
        raise ValueError("The expression is empty.")
    if not sql_guard_enabled():
        return
    if ";" in code:
        raise ValueError("An expression cannot contain ';'.")
    found = {word.lower() for word in _SQL_WORD_RE.findall(code)} & _WRITE_KEYWORDS
    if _REPLACE_INTO_RE.search(code):
        found = found | {"replace"}
    if found:
        raise ValueError(f"An expression must only compute a value, but this one uses: {', '.join(sorted(found))}.")


#: What a statement run under ``read_only`` may NOT do: anything that
#: changes the database's contents or schema. Everything else is allowed -
#: this guards the data, it does not restrict what can be read.
_WRITE_ACTIONS: frozenset[int] = frozenset(
    getattr(sqlite3, name)
    for name in (
        "SQLITE_INSERT", "SQLITE_UPDATE", "SQLITE_DELETE",
        "SQLITE_CREATE_INDEX", "SQLITE_CREATE_TABLE", "SQLITE_CREATE_TEMP_INDEX",
        "SQLITE_CREATE_TEMP_TABLE", "SQLITE_CREATE_TEMP_TRIGGER", "SQLITE_CREATE_TEMP_VIEW",
        "SQLITE_CREATE_TRIGGER", "SQLITE_CREATE_VIEW", "SQLITE_CREATE_VTABLE",
        "SQLITE_DROP_INDEX", "SQLITE_DROP_TABLE", "SQLITE_DROP_TEMP_INDEX",
        "SQLITE_DROP_TEMP_TABLE", "SQLITE_DROP_TEMP_TRIGGER", "SQLITE_DROP_TEMP_VIEW",
        "SQLITE_DROP_TRIGGER", "SQLITE_DROP_VIEW", "SQLITE_DROP_VTABLE",
        "SQLITE_ALTER_TABLE", "SQLITE_REINDEX", "SQLITE_ANALYZE",
    )
    if hasattr(sqlite3, name)
)

#: Pragmas whose argument names what to read (a table, an index), never
#: a value to set - so they are allowed with one.
_READING_PRAGMAS: frozenset[str] = frozenset(
    {
        "table_info", "table_xinfo", "table_list", "index_list", "index_info",
        "index_xinfo", "foreign_key_list", "foreign_key_check", "integrity_check",
        "quick_check", "database_list", "collation_list", "function_list",
        "module_list", "pragma_list", "compile_options",
    }
)

#: The one function refused: it loads native code that can do anything.
_DENIED_FUNCTIONS: frozenset[str] = frozenset({"load_extension"})


def _read_only_authorizer(action: int, arg1: Any, arg2: Any, _db: Any, _source: Any) -> int:
    if action in _WRITE_ACTIONS:
        return sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_PRAGMA and arg2 is not None and str(arg1 or "").lower() not in _READING_PRAGMAS:
        # "PRAGMA name = value" sets something; "PRAGMA name" only reads,
        # and so does every pragma in _READING_PRAGMAS whatever its argument.
        return sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_FUNCTION and str(arg2 or "").lower() in _DENIED_FUNCTIONS:
        return sqlite3.SQLITE_DENY
    return sqlite3.SQLITE_OK


@contextmanager
def read_only(con: sqlite3.Connection):
    """Run user-written SQL on *con* with SQLite refusing anything that writes.

    The text checks (is_read_only_select) catch the obvious cases with a
    readable message; this is the backstop that does not depend on parsing
    the SQL correctly - a statement that writes fails with "not authorized".
    """
    if not sql_guard_enabled():
        yield con
        return
    con.set_authorizer(_read_only_authorizer)
    try:
        yield con
    finally:
        con.set_authorizer(None)


def _loads_json(text: str | None) -> dict[str, Any]:
    """Parse JSON to dict; return {} on empty/invalid/non-dict input."""
    try:
        return {} if not text else dict(json.loads(text))
    except (ValueError, TypeError):  # not JSON, or not an object
        return {}


def _dumps_json(obj: Mapping[str, Any] | None = None) -> str:
    """Serialize mapping to JSON string (UTF-8)."""
    return json.dumps(dict(obj or {}), ensure_ascii=False)


def _quote_ident(name: str) -> str:
    """``data_source.quote_identifier`` of the name, stripped.

    Any name is safe once quoted, and a table called "CO2 per capita" is a
    perfectly good table: this used to log every such name as an error.
    """
    return quote_identifier((name or "").strip())


def _is_ident(name: str) -> bool:
    """Return True if name is a valid SQLite identifier."""
    return is_identifier(name)



#: What the rest of the application catches when the database refuses
#: something - every error sqlite3 raises. Re-exported by sqlite_repo so a
#: widget can catch it without importing sqlite3: SQL and its errors stay in
#: app/data (dev/tests/test_repo_boundary.py).
DatabaseError = sqlite3.Error

#: What reading a source can raise: the database refusing (sqlite3.Error),
#: pandas wrapping that refusal (its DatabaseError is an OSError), or the
#: guard blocking a query that would write (ValueError).
READ_FAILURES: tuple[type[Exception], ...] = (sqlite3.Error, OSError, ValueError)

@dataclass(slots=True)
class SavedQuery:
    """Stored SQL query descriptor."""

    id: int | None
    name: str
    sql: str
    settings: dict[str, Any]


@dataclass(slots=True)
class DatabaseReport:
    """What ``check_database`` found, grouped by how bad it is.

    The split matters: corruption and dangling references are problems the user
    must act on, while an unreferenced table is usually just data waiting to be
    charted.  Reporting them at the same severity would train the user to
    ignore the whole report.
    """

    integrity_errors: list[str] = field(default_factory=list)
    foreign_key_errors: list[str] = field(default_factory=list)
    dangling_series: list[str] = field(default_factory=list)
    dangling_links: list[str] = field(default_factory=list)
    orphan_descriptors: list[str] = field(default_factory=list)
    unreferenced_tables: list[str] = field(default_factory=list)

    @property
    def problems(self) -> list[str]:
        """Every finding that needs the user to do something."""
        return [
            *self.integrity_errors,
            *self.foreign_key_errors,
            *self.orphan_descriptors,
            *self.dangling_series,
            *self.dangling_links,
        ]

    @property
    def is_healthy(self) -> bool:
        """True when nothing actionable was found."""
        return not self.problems

    def summary(self) -> str:
        """Return a one-line summary suitable for a status bar."""
        if self.is_healthy:
            extra = (
                f" ({len(self.unreferenced_tables)} unreferenced table(s))"
                if self.unreferenced_tables
                else ""
            )
            return f"Database check passed{extra}."
        return f"Database check found {len(self.problems)} problem(s)."

    #: Every finding list, with the heading it is reported under.  One table,
    #: so the log, the summary and the detail pane cannot come to disagree
    #: about what was looked for - adding a check means adding it here.
    SECTIONS: ClassVar[tuple[tuple[str, str], ...]] = (
        ("integrity_errors", "Integrity"),
        ("foreign_key_errors", "Foreign keys"),
        ("orphan_descriptors", "Orphan descriptors"),
        ("dangling_series", "Series reading a missing table"),
        ("dangling_links", "Import links to a missing table"),
        ("unreferenced_tables", "Unreferenced tables (not a problem)"),
    )

    def details(self) -> str:
        """Return every finding, grouped under its heading, one per line.

        The summary counts them; this says what they were.  Nothing is
        truncated: a check that reports "47 problems" and then shows twenty of
        them is a check the user cannot finish acting on, and the pane this
        goes into scrolls.

        Unreferenced tables are included even though they are not problems.
        "3 unreferenced table(s)" with no way to see which three is a line
        nobody can do anything with.
        """
        lines: list[str] = []
        for attribute, heading in self.SECTIONS:
            findings = getattr(self, attribute)
            if not findings:
                continue
            if lines:
                lines.append("")
            lines.append(f"{heading}:")
            lines.extend(f"  {finding}" for finding in findings)
        return "\n".join(lines)

    def log(self) -> None:
        """Write the whole report to the log, worst first."""
        for message in self.integrity_errors:
            applogger.error(
                "Database integrity: %s", message
            )
        for message in self.foreign_key_errors:
            applogger.error(
                "Foreign key: %s", message
            )
        for message in self.orphan_descriptors:
            applogger.warning(
                "Orphan descriptor: %s", message
            )
        for message in self.dangling_series:
            applogger.warning(
                "Dangling reference: %s", message
            )
        for message in self.dangling_links:
            applogger.warning(
                "Dangling reference: %s", message
            )
        if self.unreferenced_tables:
            applogger.info(
                "Tables not used by any chart or import link: %s",
                ", ".join(self.unreferenced_tables),
            )
        applogger.info(self.summary())


@dataclass(slots=True)
class DatabasePragmaInfo:
    """Everything SQLite itself can say about the connected database file.

    Read-only PRAGMAs and the file's own OS timestamps, for the Database
    Info dialog's "Info" section - not a health check (see DatabaseReport
    for that), just what the engine and the filesystem already know
    without being asked to compute anything.
    """

    sqlite_version: str
    page_size: int
    page_count: int
    freelist_count: int
    encoding: str
    journal_mode: str
    application_id: int
    user_version: int
    table_count: int
    total_rows: int
    #: None when the OS this runs on does not expose a true creation time
    #: (Linux's st_ctime is "last metadata change", not creation - see
    #: database_pragma_info's own docstring).
    file_created: datetime | None = None
    file_modified: datetime | None = None

    @property
    def size_bytes(self) -> int:
        """The database file's logical size - page_size x page_count."""
        return self.page_size * self.page_count

    @property
    def reclaimable_bytes(self) -> int:
        """What VACUUM would free - the free pages already counted in
        size_bytes but holding nothing live."""
        return self.page_size * self.freelist_count


# ---------------------------------------------------------------------------
# What each mixin may call on the repository it is mixed into
# ---------------------------------------------------------------------------
# The mixins are halves of one class, SqliteRepo, and call into each other
# and into it - TablesMixin asks for get_axes (DescriptorsMixin), everything
# asks for _con. At run time that is just the method resolution order; a
# type checker looking at one mixin alone sees none of it, and reported
# every such call as an unknown attribute (~350 errors). RepoHost names
# those members once, for the checker only: at run time it is ``object``,
# so nothing here can shadow the real definitions, which sit earlier in the
# MRO anyway. The signatures are copies - change one with its original.
if TYPE_CHECKING:
    from collections.abc import Sequence
    from contextlib import AbstractContextManager
    from pathlib import Path

    import pandas as pd

    from app.data.descriptors import FigureDescriptor

    class RepoHost:
        db_path: Path
        _con: sqlite3.Connection | None
        _is_connected: bool

        def _connect(self) -> None: ...
        def _commit(self) -> None: ...
        def transaction(self, *, immediate: bool = False) -> AbstractContextManager[None]: ...
        def refuse_if_blocked(self, sql: str | None) -> None: ...
        def snapshot_for_undo(
            self,
            tables: Sequence[str],
            *,
            label: str,
            entry_id: int | None = None,
        ) -> int | None: ...
        @staticmethod
        def ensure_dhub_extension(path: Path) -> Path: ...

        # TablesMixin, FlagsMixin
        def list_user_tables(self, *, include_internal: bool = False) -> pd.DataFrame: ...
        def row_count(self, table: str) -> int: ...
        def table_info(self, table: str) -> list[sqlite3.Row]: ...
        def get_columns(self, table: str) -> list[str]: ...
        def has_column(self, table_name: str, col_name: str) -> bool: ...
        def ensure_column(self, table_name: str, col_name: str, col_type: str = "INTEGER") -> None: ...
        @staticmethod
        def sql_without_hide_filter(sql_query: str) -> str: ...
        def query_df(self, sql: str, params: tuple[Any, ...] | None = None) -> pd.DataFrame: ...
        def ensure_hide_column(self, table_name: str) -> None: ...
        def query_source_table(self, sql_query: str) -> str: ...
        @staticmethod
        def is_table_backed_sql(sql_query: str) -> bool: ...
        def sql_with_hide_filter(self, sql_query: str) -> str: ...
        def list_table_names(self) -> list[str]: ...
        def check_if_table_exists(self, table_name: str) -> bool: ...

        # EditingMixin
        def has_integer_primary_key(self, table_name: str) -> bool: ...

        # DescriptorsMixin
        def get_figure_descriptor(self, figure_id: int) -> FigureDescriptor | None: ...
        def update_series_sql_query(self, series_id: int, sql_query: str) -> None: ...
        def get_series_sql_query(self, series_id: int) -> str | None: ...
        def list_series_dict(self) -> list[dict[str, Any]]: ...
        def get_series_for_axes(self, axis_ids: Sequence[int]) -> dict[int, list[sqlite3.Row]]: ...
        def get_axes(self, figure_id: int) -> list[sqlite3.Row] | None: ...

        # QueriesMixin
        def get_query(self, name: str) -> SavedQuery | None: ...
        def list_queries(self) -> list[SavedQuery]: ...
else:
    RepoHost = object
